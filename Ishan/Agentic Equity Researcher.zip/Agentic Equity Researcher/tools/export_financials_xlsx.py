"""Excel export of a ticker's extracted financials — deterministic, zero
tokens (openpyxl). Reads workspace/<TICKER>/ directly and writes
workspace/<TICKER>/exports/<TICKER>_financials.xlsx.

Ported verbatim from the fund repo (D:\\Documents\\Claude\\1Projects\\AI
Native Fund, research/equity_researcher/tools/export_financials_xlsx.py) —
no fund imports there either, so no adaptation was needed for this
standalone copy.

Sheets:
  IS_tree / BS_tree / CF_tree   3-level indented line-item tree (mirrors
                                 state/comprehensive_statement.json), one
                                 sheet per statement, periods as columns,
                                 indentation encoded via cell indent level 1:1
                                 with the tree's `level` field.
  Quarterly                     same tree data but restricted to Q/H period
                                 columns only (the *_tree sheets show every
                                 period; this sheet is the quarter-only cut).
  Ratios                        computed ratios from facts/derived_metrics.json
                                 (metric x FY, mirrors render_tables.py's
                                 ratio_summary spec).
  EPS_Bridge                    mirrors state/eps_bridge_check.json — one row
                                 per rule_id with status/value/threshold/note.
  RedFlags                      mirrors state/red_flags.json ledger.

Usage:
  python tools/export_financials_xlsx.py workspace/TICKER
      [--out workspace/TICKER/exports/TICKER_financials.xlsx]

No fund imports (standalone ER must stay self-contained).
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font
from openpyxl.utils import get_column_letter

HEADER_FONT = Font(bold=True)
TITLE_FONT = Font(bold=True, size=12)


def _load_json(path: Path, default):
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return default


# --- tree sheets (IS_tree / BS_tree / CF_tree / Quarterly) -----------------

def _all_periods(tree: dict) -> list[str]:
    periods: set[str] = set()

    def walk(node: dict):
        periods.update((node.get("values") or {}).keys())
        for c in node.get("children") or []:
            walk(c)

    for root in tree.values():
        walk(root)
    return sorted(periods, key=lambda p: (0 if p.startswith("FY") and len(p) == 6 else 1, p))


def _fmt_cell_value(entry: dict | None):
    if entry is None:
        return None
    v = entry.get("value")
    if isinstance(v, (int, float)):
        return v
    return v  # leave strings / None as-is; openpyxl handles both


def _write_tree_sheet(ws, tree: dict, periods: list[str], basis: str | None = None):
    ws.append(["Line item"] + periods)
    for c in ws[1]:
        c.font = HEADER_FONT

    def write_node(node: dict, row_cursor: list[int]):
        row_cursor[0] += 1
        r = row_cursor[0]
        level = node.get("level", 1) or 1
        label_cell = ws.cell(row=r, column=1, value=node.get("label") or node.get("metric"))
        label_cell.alignment = Alignment(indent=max(level - 1, 0) * 2)
        values = node.get("values") or {}
        for ci, period in enumerate(periods, start=2):
            entry = values.get(period)
            if entry is not None and basis is not None and entry.get("basis") not in (basis, "na"):
                entry = None
            ws.cell(row=r, column=ci, value=_fmt_cell_value(entry))
        for child in sorted(node.get("children") or [], key=lambda n: n.get("label") or ""):
            write_node(child, row_cursor)

    row_cursor = [1]
    for root in sorted(tree.values(), key=lambda n: n.get("label") or ""):
        write_node(root, row_cursor)

    ws.column_dimensions["A"].width = 42
    for ci in range(2, len(periods) + 2):
        ws.column_dimensions[get_column_letter(ci)].width = 14


def _dominant_basis(tree: dict) -> str | None:
    bases: dict[str, int] = {}

    def walk(node: dict):
        for entry in (node.get("values") or {}).values():
            b = entry.get("basis")
            if b and b != "na":
                bases[b] = bases.get(b, 0) + 1
        for c in node.get("children") or []:
            walk(c)

    for root in tree.values():
        walk(root)
    if not bases:
        return None
    return max(bases, key=bases.get)


def _add_statement_sheet(wb: Workbook, sheet_name: str, tree: dict):
    ws = wb.create_sheet(sheet_name)
    if not tree:
        ws.append(["No data — comprehensive_statement.json has no entries for this statement."])
        return
    periods = _all_periods(tree)
    basis = _dominant_basis(tree)
    _write_tree_sheet(ws, tree, periods, basis=basis)


def _add_quarterly_sheet(wb: Workbook, comp_statement: dict):
    ws = wb.create_sheet("Quarterly")
    q_periods: set[str] = set()

    def collect_periods(tree: dict):
        def walk(node):
            for p in (node.get("values") or {}):
                if not (p.startswith("FY") and len(p) == 6):  # exclude plain FYxxxx annual columns
                    q_periods.add(p)
            for c in node.get("children") or []:
                walk(c)
        for root in tree.values():
            walk(root)

    for stmt_key in ("income_statement", "balance_sheet", "cash_flow"):
        collect_periods(comp_statement.get(stmt_key, {}) or {})

    periods = sorted(q_periods)
    if not periods:
        ws.append(["No quarterly/half-year periods found in comprehensive_statement.json."])
        return

    ws.append(["Statement", "Line item"] + periods)
    for c in ws[1]:
        c.font = HEADER_FONT

    row = 1
    for stmt_key, stmt_label in (
        ("income_statement", "Income Statement"),
        ("balance_sheet", "Balance Sheet"),
        ("cash_flow", "Cash Flow"),
    ):
        tree = comp_statement.get(stmt_key, {}) or {}
        basis = _dominant_basis(tree)

        def write_node(node: dict):
            nonlocal row
            row += 1
            values = node.get("values") or {}
            level = node.get("level", 1) or 1
            label_cell = ws.cell(row=row, column=2, value=node.get("label") or node.get("metric"))
            label_cell.alignment = Alignment(indent=max(level - 1, 0) * 2)
            ws.cell(row=row, column=1, value=stmt_label)
            for ci, period in enumerate(periods, start=3):
                entry = values.get(period)
                if entry is not None and basis is not None and entry.get("basis") not in (basis, "na"):
                    entry = None
                ws.cell(row=row, column=ci, value=_fmt_cell_value(entry))
            for child in sorted(node.get("children") or [], key=lambda n: n.get("label") or ""):
                write_node(child)

        for root in sorted(tree.values(), key=lambda n: n.get("label") or ""):
            write_node(root)

    ws.column_dimensions["A"].width = 18
    ws.column_dimensions["B"].width = 40
    for ci in range(3, len(periods) + 3):
        ws.column_dimensions[get_column_letter(ci)].width = 14


# --- Ratios sheet ------------------------------------------------------------

RATIO_METRICS = [
    ("gross_margin", "Gross margin %"),
    ("ebitda_margin", "EBITDA margin %"),
    ("net_margin", "PAT margin %"),
    ("roe", "ROE %"),
    ("roce", "ROCE %"),
    ("asset_turnover", "Asset turnover (x)"),
    ("dso_days", "Receivable days"),
    ("inventory_days", "Inventory days"),
    ("payable_days", "Payable days"),
    ("ccc_days", "Cash conversion cycle (days)"),
    ("current_ratio", "Current ratio (x)"),
    ("debt_equity", "Debt/Equity (x)"),
    ("interest_coverage", "Interest coverage (x)"),
    ("net_debt_ebitda", "Net debt/EBITDA (x)"),
    ("cfo_to_ebitda", "CFO/EBITDA %"),
    ("fcf", "Free cash flow (INR cr)"),
]


def _add_ratios_sheet(wb: Workbook, derived_facts: list[dict]):
    ws = wb.create_sheet("Ratios")
    live = [f for f in derived_facts if "superseded" not in (f.get("flags") or [])]
    periods = sorted({f.get("period") for f in live if f.get("period") and f.get("period").startswith("FY") and len(f.get("period")) == 6})
    if not periods:
        ws.append(["No derived_metrics.json ratio facts found (run tools/compute_ratios.py first)."])
        return

    idx: dict[tuple, dict] = {}
    for f in live:
        key = (f.get("metric"), f.get("period"))
        idx.setdefault(key, f)  # first wins; derived facts have no reported/computed collision here

    ws.append(["Ratio"] + periods)
    for c in ws[1]:
        c.font = HEADER_FONT
    for metric, label in RATIO_METRICS:
        row = [label]
        for p in periods:
            f = idx.get((metric, p))
            row.append(f.get("value") if f else None)
        ws.append(row)

    ws.column_dimensions["A"].width = 32
    for ci in range(2, len(periods) + 2):
        ws.column_dimensions[get_column_letter(ci)].width = 14


# --- EPS_Bridge sheet ---------------------------------------------------------

def _add_eps_bridge_sheet(wb: Workbook, eps_bridge_check: dict):
    ws = wb.create_sheet("EPS_Bridge")
    ws.append(["Rule", "Status", "Value", "Threshold", "Note"])
    for c in ws[1]:
        c.font = HEADER_FONT
    if not eps_bridge_check:
        ws.append(["No eps_bridge_check.json found — run tools/eps_bridge_check.py first.", "", "", "", ""])
        return
    for rule_id, result in eps_bridge_check.items():
        if rule_id.startswith("_"):
            continue  # skip _basis / _periods metadata keys
        if not isinstance(result, dict):
            continue
        value = result.get("value")
        value_str = json.dumps(value, ensure_ascii=False) if isinstance(value, (dict, list)) else value
        ws.append([rule_id, result.get("status"), value_str, result.get("threshold"), result.get("note")])

    ws.column_dimensions["A"].width = 30
    ws.column_dimensions["B"].width = 10
    ws.column_dimensions["C"].width = 40
    ws.column_dimensions["D"].width = 14
    ws.column_dimensions["E"].width = 60
    for row in ws.iter_rows(min_row=2):
        row[4].alignment = Alignment(wrap_text=True)


# --- RedFlags sheet ------------------------------------------------------------

RED_FLAG_COLUMNS = ["id", "category", "flag", "status", "severity", "confidence", "threshold", "owner"]


def _add_red_flags_sheet(wb: Workbook, red_flags: list[dict]):
    ws = wb.create_sheet("RedFlags")
    ws.append([c.replace("_", " ").title() for c in RED_FLAG_COLUMNS])
    for c in ws[1]:
        c.font = HEADER_FONT
    if not red_flags:
        ws.append(["No red_flags.json entries found." if True else ""] + [""] * (len(RED_FLAG_COLUMNS) - 1))
        return
    for entry in red_flags:
        ws.append([entry.get(col) for col in RED_FLAG_COLUMNS])

    ws.column_dimensions["A"].width = 10
    ws.column_dimensions["C"].width = 60
    for ci in range(1, len(RED_FLAG_COLUMNS) + 1):
        letter = get_column_letter(ci)
        if letter not in ("A", "C"):
            ws.column_dimensions[letter].width = 16


# --- orchestration -------------------------------------------------------------

def export_ticker(workspace_dir: Path, out_path: Path | None = None) -> Path:
    workspace_dir = Path(workspace_dir)
    ticker = workspace_dir.name

    comp_statement = _load_json(workspace_dir / "state" / "comprehensive_statement.json", {})
    derived = _load_json(workspace_dir / "facts" / "derived_metrics.json", {})
    derived_facts = derived.get("facts", derived) if isinstance(derived, dict) else (derived or [])
    eps_bridge_check = _load_json(workspace_dir / "state" / "eps_bridge_check.json", {})
    red_flags = _load_json(workspace_dir / "state" / "red_flags.json", [])
    if isinstance(red_flags, dict):
        red_flags = red_flags.get("flags", red_flags.get("red_flags", []))

    wb = Workbook()
    wb.remove(wb.active)  # drop the default blank sheet; we add named ones below

    _add_statement_sheet(wb, "IS_tree", comp_statement.get("income_statement", {}) or {})
    _add_statement_sheet(wb, "BS_tree", comp_statement.get("balance_sheet", {}) or {})
    _add_statement_sheet(wb, "CF_tree", comp_statement.get("cash_flow", {}) or {})
    _add_quarterly_sheet(wb, comp_statement)
    _add_ratios_sheet(wb, derived_facts)
    _add_eps_bridge_sheet(wb, eps_bridge_check)
    _add_red_flags_sheet(wb, red_flags)

    if out_path is None:
        out_path = workspace_dir / "exports" / f"{ticker}_financials.xlsx"
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(out_path)
    return out_path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("workspace_dir", help="workspace/TICKER directory")
    ap.add_argument("--out", default=None, help="output xlsx path (default: workspace/TICKER/exports/TICKER_financials.xlsx)")
    a = ap.parse_args()

    out_path = export_ticker(Path(a.workspace_dir), Path(a.out) if a.out else None)
    print(f"OK: financials export -> {out_path}")


if __name__ == "__main__":
    main()
