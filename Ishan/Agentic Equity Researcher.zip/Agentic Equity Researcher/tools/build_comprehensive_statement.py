"""Comprehensive statement builder — deterministic, zero tokens.

Reads the merged facts store (output of tools/merge_facts.py, i.e.
facts/financials.json — optionally also facts/derived_metrics.json for
computed ratios) and assembles a single authoritative multi-period view:

  workspace/<TICKER>/state/comprehensive_statement.json
      For each statement (income_statement / balance_sheet / cash_flow): a
      line-item TREE (level 1 -> level 2 -> level 3 children) x all fiscal
      years and available quarters/halves. Each node:
        {"label": str, "metric": str, "level": int,
         "values": {period: {"value": ..., "unit": ..., "basis": ...,
                              "fact_id": ..., "method": ...}, ...},
         "fact_ids": [...], "children": [...]}

  workspace/<TICKER>/state/comprehensive_statement.md
      Rendered indented multi-year table per statement (one table per
      basis found: consolidated / standalone).

Statement assignment: each Level-1 (root, parent=null) metric is classified
into income_statement / balance_sheet / cash_flow / other via a keyword
heuristic aligned with prompts/10's Part 1/2/3 vocabulary. Level 2/3 records
inherit their root's statement by walking the `parent` chain; a record whose
parent chain cannot be resolved to a known root is filed under "unclassified"
so nothing is silently dropped.

Handles missing levels gracefully: a metric with only Level 1 present still
renders (no Level 2/3 children); Level 3 without any Level 2 is nested
directly under Level 1 as an orphan child, flagged in its node as
"orphan_level": true, rather than being dropped.

Usage:
  python tools/build_comprehensive_statement.py workspace/TICKER/facts/financials.json \
      --out-json workspace/TICKER/state/comprehensive_statement.json \
      --out-md workspace/TICKER/state/comprehensive_statement.md \
      [--derived workspace/TICKER/facts/derived_metrics.json]
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

# --- statement classification (Level-1 / root metrics only) ---------------

INCOME_STATEMENT_KEYWORDS = (
    "revenue", "other_income", "total_expenses", "ebitda", "depreciation",
    "amortization", "finance_costs", "pbt", "tax", "pat", "minority_interest",
    "eps", "weighted_shares", "cost_of_materials", "purchases_stock_in_trade",
    "changes_in_inventories", "employee_benefits", "power_fuel", "freight",
    "sub_contracting", "other_expenses", "exceptional_item",
)
BALANCE_SHEET_KEYWORDS = (
    "total_assets", "total_equity", "ppe", "cwip", "intangibles",
    "investments", "inventories", "trade_receivables", "cash_and_bank",
    "borrowings", "trade_payables", "provisions", "contingent_liabilities",
    "deferred_tax", "current_assets", "current_liabilities", "net_debt",
    "gross_receivables", "allowance_doubtful_accounts",
)
CASH_FLOW_KEYWORDS = (
    "cfo", "cfi", "cff", "purchase_of_ppe", "purchase_of_intangibles",
    "sale_of_ppe", "net_capex", "fcf", "working_capital_movement",
    "cash_flow",
)

STATEMENT_LABELS = {
    "income_statement": "Income Statement",
    "balance_sheet": "Balance Sheet",
    "cash_flow": "Cash Flow",
    "unclassified": "Unclassified / Other",
}


def classify_root(metric: str) -> str:
    m = metric.lower()
    if any(k in m for k in CASH_FLOW_KEYWORDS):
        return "cash_flow"
    if any(k in m for k in BALANCE_SHEET_KEYWORDS):
        return "balance_sheet"
    if any(k in m for k in INCOME_STATEMENT_KEYWORDS):
        return "income_statement"
    return "unclassified"


# --- loading ----------------------------------------------------------------

def load_facts(path: Path) -> list[dict]:
    if not path.exists():
        return []
    data = json.loads(path.read_text(encoding="utf-8"))
    recs = data.get("facts", data) if isinstance(data, dict) else data
    return [r for r in recs if isinstance(r, dict)]


def is_live(rec: dict) -> bool:
    return "superseded" not in (rec.get("flags") or [])


# --- tree assembly ------------------------------------------------------

class Node:
    __slots__ = ("label", "metric", "level", "values", "fact_ids", "children", "orphan_level")

    def __init__(self, metric: str, label: str, level: int):
        self.metric = metric
        self.label = label
        self.level = level
        self.values: dict[str, dict] = {}
        self.fact_ids: list[str] = []
        self.children: dict[str, "Node"] = {}
        self.orphan_level = False

    def to_dict(self) -> dict:
        return {
            "label": self.label,
            "metric": self.metric,
            "level": self.level,
            "values": self.values,
            "fact_ids": sorted(set(self.fact_ids)),
            "orphan_level": self.orphan_level,
            "children": [c.to_dict() for c in self.children.values()],
        }


def build_trees(facts: list[dict]) -> dict[str, dict[str, Node]]:
    """Returns {statement: {metric: root_node}} — root_node subtrees hold
    level-2/3 children keyed by metric name."""
    live = [f for f in facts if is_live(f)]
    by_metric_fact_ids: dict[str, str] = {}  # metric -> a representative fact id (any period) for parent-chain lookups
    parent_of: dict[str, str | None] = {}    # metric -> parent metric (from any record carrying that metric)
    level_of: dict[str, int] = {}
    label_of: dict[str, str] = {}

    for r in live:
        metric = r.get("metric")
        if not metric:
            continue
        level_of.setdefault(metric, r.get("level", 1) or 1)
        label_of.setdefault(metric, r.get("label") or metric)
        parent_metric = r.get("parent")
        # `parent` in fact records is documented as a fact id, but extractors in
        # practice may emit either a fact id or a metric name; resolve by metric
        # name when possible, else keep the raw value for id-based lookups below.
        if parent_metric:
            parent_of.setdefault(metric, parent_metric)
        by_metric_fact_ids.setdefault(metric, r.get("id"))

    # map fact id -> metric, for resolving parent fields that are fact ids
    id_to_metric = {r.get("id"): r.get("metric") for r in live if r.get("id")}

    def resolve_parent_metric(metric: str) -> str | None:
        p = parent_of.get(metric)
        if not p:
            return None
        if p in level_of:  # already a metric name
            return p
        return id_to_metric.get(p)  # else treat as fact id

    # roots = level 1 metrics (or metrics with no resolvable parent)
    roots: dict[str, str] = {}  # metric -> statement
    for metric, lvl in level_of.items():
        if lvl == 1 or resolve_parent_metric(metric) is None:
            roots[metric] = classify_root(metric)

    trees: dict[str, dict[str, Node]] = {s: {} for s in STATEMENT_LABELS}

    def get_or_create(statement: str, metric: str, level: int) -> Node:
        bucket = trees[statement]
        if metric not in bucket:
            bucket[metric] = Node(metric, label_of.get(metric, metric), level)
        return bucket[metric]

    # build node registry across all metrics first (flat), then link parent->child
    all_nodes: dict[str, Node] = {}
    metric_statement: dict[str, str] = {}

    def statement_for(metric: str, _seen=None) -> str:
        if metric in metric_statement:
            return metric_statement[metric]
        _seen = _seen or set()
        if metric in _seen:
            return "unclassified"
        _seen.add(metric)
        if metric in roots:
            stmt = roots[metric]
        else:
            p = resolve_parent_metric(metric)
            stmt = statement_for(p, _seen) if p else classify_root(metric)
        metric_statement[metric] = stmt
        return stmt

    for metric, level in level_of.items():
        stmt = statement_for(metric)
        node = Node(metric, label_of.get(metric, metric), level)
        all_nodes[metric] = node
        metric_statement[metric] = stmt

    # attach values + fact_ids from every live record onto its node
    for r in live:
        metric = r.get("metric")
        if not metric or metric not in all_nodes:
            continue
        node = all_nodes[metric]
        period = r.get("period")
        if period:
            node.values[period] = {
                "value": r.get("value"),
                "unit": r.get("unit"),
                "basis": r.get("basis"),
                "fact_id": r.get("id"),
                "method": r.get("method"),
            }
        if r.get("id"):
            node.fact_ids.append(r["id"])

    # link children to parents; roots go into `trees[statement]`
    for metric, node in all_nodes.items():
        stmt = metric_statement[metric]
        parent_metric = resolve_parent_metric(metric)
        if parent_metric and parent_metric in all_nodes and parent_metric != metric:
            parent_node = all_nodes[parent_metric]
            # graceful missing-level handling: if this is level 3 but parent is
            # level 1 (no level-2 in between), mark it an orphan child rather
            # than dropping it.
            if node.level == 3 and parent_node.level == 1:
                node.orphan_level = True
            parent_node.children[metric] = node
        else:
            trees[stmt][metric] = node

    return trees


# --- rendering ------------------------------------------------------------

def all_periods(trees: dict[str, dict[str, Node]]) -> list[str]:
    periods: set[str] = set()

    def walk(node: Node):
        periods.update(node.values.keys())
        for c in node.children.values():
            walk(c)

    for bucket in trees.values():
        for root in bucket.values():
            walk(root)
    return sorted(periods, key=lambda p: (0 if p.startswith("FY") else 1, p))


def fmt_value(v) -> str:
    if v is None:
        return "N/A"
    if isinstance(v, (int, float)):
        return f"{v:,.1f}"
    return str(v)


def render_node(node: Node, periods: list[str], basis: str, indent: int, lines: list[str]):
    cells = []
    for p in periods:
        entry = node.values.get(p)
        if entry is None or (entry.get("basis") not in (basis, "na")):
            cells.append("")
        else:
            cells.append(fmt_value(entry.get("value")))
    prefix = "  " * indent + ("- " if indent else "")
    lines.append(f"| {prefix}{node.label} | " + " | ".join(cells) + " |")
    for child in sorted(node.children.values(), key=lambda n: n.label):
        render_node(child, periods, basis, indent + 1, lines)


def render_markdown(trees: dict[str, dict[str, Node]]) -> str:
    periods = all_periods(trees)
    bases: set[str] = set()

    def collect_bases(node: Node):
        for entry in node.values.values():
            b = entry.get("basis")
            if b and b != "na":
                bases.add(b)
        for c in node.children.values():
            collect_bases(c)

    for bucket in trees.values():
        for root in bucket.values():
            collect_bases(root)
    if not bases:
        bases = {"consolidated"}

    out = ["# Comprehensive Statement (3-level, all periods)", ""]
    if not periods:
        out.append("*No periods found in facts store.*")
        return "\n".join(out)

    for statement, label in STATEMENT_LABELS.items():
        bucket = trees.get(statement, {})
        if not bucket:
            continue
        out.append(f"## {label}")
        out.append("")
        for basis in sorted(bases):
            out.append(f"### Basis: {basis}")
            out.append("")
            lines = ["| Line item | " + " | ".join(periods) + " |",
                     "|---" * (len(periods) + 1) + "|"]
            for root in sorted(bucket.values(), key=lambda n: n.label):
                render_node(root, periods, basis, 0, lines)
            out.extend(lines)
            out.append("")
    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("facts_file", help="merged facts store, e.g. workspace/TICKER/facts/financials.json")
    ap.add_argument("--derived", default=None, help="optional derived_metrics.json to include computed ratios")
    ap.add_argument("--out-json", required=True)
    ap.add_argument("--out-md", required=True)
    a = ap.parse_args()

    facts = load_facts(Path(a.facts_file))
    if a.derived:
        facts += load_facts(Path(a.derived))

    trees = build_trees(facts)

    json_out = {
        statement: {metric: node.to_dict() for metric, node in bucket.items()}
        for statement, bucket in trees.items()
    }

    out_json_path = Path(a.out_json)
    out_json_path.parent.mkdir(parents=True, exist_ok=True)
    out_json_path.write_text(json.dumps(json_out, indent=2, ensure_ascii=False), encoding="utf-8")

    md = render_markdown(trees)
    out_md_path = Path(a.out_md)
    out_md_path.parent.mkdir(parents=True, exist_ok=True)
    out_md_path.write_text(md, encoding="utf-8")

    counts = {s: len(b) for s, b in trees.items()}
    print(f"OK: comprehensive statement -> {out_json_path} + {out_md_path}; root counts: {counts}")


if __name__ == "__main__":
    main()
