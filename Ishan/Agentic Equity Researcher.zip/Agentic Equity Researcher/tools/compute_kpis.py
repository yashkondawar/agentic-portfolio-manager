"""Deterministic operating-KPI & unit-economics engine (v2 process, step 3b COMPUTE).

`compute_ratios.py` does accounting ratios off the P&L/BS/CF. It cannot do PER-UNIT
economics because those need OPERATING VOLUMES (production/sales quantities, capacity)
joined to SEGMENT financials — data that lives in different facts. This tool does that
join and emits the operating-KPI trend tables a real research note carries (see
docs/PROCESS_V2_REIMAGINED.md §4). Zero LLM tokens.

It is driven, when available, by `state/business_model.json` (the KPI tree + unit-economics
map from prompt 03): each KPI names its input metrics, and we divide them period by period.
When the map is absent or an input doesn't resolve, it falls back to a keyword library for
the common patterns (segment margins, realization, utilization) and reports what it could
NOT resolve, so the extraction-feedback loop can fill the gap.

Outputs:
  facts/kpis.json      — KPI fact records (method=computed, formula + input ids)
  state/kpi_trends.md  — rendered trend tables (KPI x periods, with YoY on FY)

Usage:
  python tools/compute_kpis.py workspace/TICKER/facts/financials.json \
      --out workspace/TICKER/facts/kpis.json \
      --out-md workspace/TICKER/state/kpi_trends.md \
      [--business-model workspace/TICKER/state/business_model.json]

Design: match-tolerant (metric names vary across extractors), never crashes on missing
inputs, always reports what it resolved vs skipped.
"""
from __future__ import annotations
import argparse, json, re
from pathlib import Path


def num(v):
    try:
        return float(str(v).replace(",", ""))
    except (TypeError, ValueError):
        return None


def norm(s):
    """Normalize a metric name for fuzzy matching: lowercase alnum tokens."""
    return set(re.findall(r"[a-z0-9]+", str(s).lower()))


class FactStore:
    """Indexes non-superseded numeric facts by (metric, period, basis), and keeps the raw
    list for fuzzy keyword resolution."""

    def __init__(self, facts):
        self.rows = []
        self.exact = {}
        for f in facts:
            if "superseded" in (f.get("flags") or []):
                continue
            v = num(f.get("value"))
            if v is None:
                continue
            metric = f.get("metric") or f.get("label") or ""
            period = f.get("period")
            basis = f.get("basis") or "na"
            row = {"metric": metric, "tokens": norm(metric) | norm(f.get("label")),
                   "period": period, "basis": basis, "value": v,
                   "id": f.get("id"), "unit": f.get("unit"), "level": f.get("level", 1)}
            self.rows.append(row)
            key = (metric, period, basis)
            if key not in self.exact or row["level"] < self.exact[key]["level"]:
                self.exact[key] = row

    def bases(self):
        b = sorted({r["basis"] for r in self.rows if r["basis"] in ("standalone", "consolidated")})
        return b or sorted({r["basis"] for r in self.rows}) or ["na"]

    def periods(self, basis, kind="FY"):
        out = set()
        for r in self.rows:
            if r["basis"] != basis:
                continue
            p = r["period"] or ""
            if kind == "FY" and re.fullmatch(r"FY\d{4}", p):
                out.add(p)
            elif kind == "Q" and re.search(r"Q[1-4]", p):
                out.add(p)
        return sorted(out)

    def get_exact(self, metric, period, basis):
        r = self.exact.get((metric, period, basis))
        return (r["value"], r["id"]) if r else (None, None)

    def find(self, must, any_of=None, period=None, basis=None):
        """Fuzzy: return (value, id, metric) whose tokens are a SUPERSET of `must` and
        intersect `any_of`, for a given period/basis. Prefer the lowest-level, shortest name."""
        must = set(must)
        cands = []
        for r in self.rows:
            if period is not None and r["period"] != period:
                continue
            if basis is not None and r["basis"] != basis:
                continue
            if not must.issubset(r["tokens"]):
                continue
            if any_of and not (set(any_of) & r["tokens"]):
                continue
            cands.append(r)
        if not cands:
            return (None, None, None)
        cands.sort(key=lambda r: (r["level"], len(r["tokens"])))
        return (cands[0]["value"], cands[0]["id"], cands[0]["metric"])


class Emitter:
    def __init__(self):
        self.facts = []
        self.skipped = []
        self._seq = 0

    def emit(self, metric, period, basis, value, unit, formula, inputs):
        if value is None:
            return None
        self._seq += 1
        rid = f"K-{re.sub(r'[^A-Z0-9]', '', metric.upper())[:20]}-{period}-{basis[:4].upper()}-{self._seq:03d}"
        self.facts.append({
            "id": rid, "metric": metric, "label": metric, "value": round(value, 4),
            "unit": unit, "period": period, "period_type": "Q" if re.search(r"Q[1-4]", period) else "FY",
            "basis": basis, "level": 2, "parent": None,
            "source": {"src_id": "DERIVED-KPI", "quote": None}, "method": "computed",
            "formula": formula, "inputs": [i for i in inputs if i],
            "confidence": "high", "load_bearing": False, "flags": ["operating_kpi"]})
        return value

    def skip(self, why):
        self.skipped.append(why)


# ---- keyword-library KPIs (fallback when business_model.json is absent/incomplete) -------
# The library is DELIBERATELY LIMITED to segment margins & EBIT-contribution, and it is
# sanity-bounded: it emits only values in a plausible range. Per-unit economics
# (realization/tonne, EBIT/tonne, utilization) are NOT attempted here because they need
# unit-matched inputs (₹cr vs '000t vs MTPA) that only the business_model.json kpi_tree
# supplies reliably — when the map is absent, those are recorded as skips, not guessed.
# Segment detection is generic: it reads any "... segment ... revenue/result/ebit" fact and
# groups by the descriptive token, so it works whatever a company calls its segments
# (e.g. NALCO's alumina segment is reported as "Chemical").
SEG_VALUE = {"revenue", "sales", "turnover", "income"}
SEG_EBIT = {"ebit", "result", "results", "profit", "pbit"}
NON_SEG_TOKENS = {"segment", "reportable", "total", "unallocated", "reconciliation", "inter",
                  "segmental", "inr", "cr", "mn", "rs", "fy", "q", "for", "the", "of", "and",
                  "before", "after", "exceptional", "interest", "items", "tax", "year"}
# comparative-year facts (extractors emit the base-period fact separately; these double-count
# and mislabel the series) — drop them from the segment scan.
COMPARATIVE = {"prior", "previous", "comparative", "py", "restated"}


def _canon_segment(tokens):
    """Short, canonical segment label from descriptive tokens; None if not a clean segment."""
    label_tokens = sorted(t.rstrip("s") for t in (tokens - NON_SEG_TOKENS - SEG_VALUE - SEG_EBIT))
    stop = {"all", "other", "othe", "misc", "various", "each", "any", "net", "gross"}
    label_tokens = [t for t in label_tokens if len(t) > 2 and t not in stop]
    # collapse duplicates like {"chemical","chemicals"} -> {"chemical"}
    label_tokens = sorted(set(label_tokens))
    if not label_tokens or len(label_tokens) > 2:   # >2 tokens => descriptive junk, not a segment
        return None
    return "_".join(label_tokens)


def _segment_facts(st, period, basis, want):
    """Return {segment_label: (value, id)} for clean, base-period segment facts carrying a
    `want` token. Works whatever a company names its segments (NALCO's alumina = 'Chemical')."""
    out = {}
    for r in st.rows:
        if r["period"] != period or r["basis"] != basis:
            continue
        t = r["tokens"]
        if ("segment" not in t and "segmental" not in t) or not (t & want) or (t & COMPARATIVE):
            continue
        label = _canon_segment(t)
        if label and label not in out:
            out[label] = (r["value"], r["id"])
    return out


def library_kpis(st, em):
    """Segment EBIT margin + EBIT contribution only, sanity-bounded, requiring >=2 segments
    for contribution so it can't be trivially 100%."""
    attempted_unit_econ = False
    for basis in st.bases():
        for kind in ("FY", "Q"):
            for period in st.periods(basis, kind):
                revs = _segment_facts(st, period, basis, SEG_VALUE)
                ebits = _segment_facts(st, period, basis, SEG_EBIT)
                total_ebit = sum(v for v, _ in ebits.values()) if ebits else None
                for seg, (ev, eid) in ebits.items():
                    rv, rid = revs.get(seg, (None, None))
                    if rv:
                        margin = ev / rv * 100
                        if -100 <= margin <= 100:   # sanity bound; else likely a row/unit mismatch
                            em.emit(f"{seg}_segment_ebit_margin", period, basis, margin, "pct",
                                    f"{seg} segment ebit / {seg} segment revenue * 100", [eid, rid])
                        else:
                            em.skip(f"{seg} ebit_margin {period} {basis}: {margin:.0f}% out of range "
                                    f"(row/unit mismatch — needs business_model.json kpi_tree)")
                    if total_ebit not in (None, 0) and len(ebits) >= 2:
                        em.emit(f"{seg}_ebit_contribution", period, basis, ev / total_ebit * 100, "pct",
                                f"{seg} segment ebit / total segment ebit * 100", [eid])
                # note the per-unit economics we are deliberately NOT guessing
                if not attempted_unit_econ:
                    em.skip("per-unit economics (realization/tonne, EBIT/tonne, utilization) not "
                            "computed from the keyword library — provide state/business_model.json "
                            "kpi_tree with unit-matched inputs so these compute reliably")
                    attempted_unit_econ = True


# ---- business-model-driven KPIs (preferred path) ----------------------------------------
def tree_kpis(st, em, bm):
    """Compute each computable kpi_tree entry whose two named inputs resolve. Ratio KPIs
    with a 'pct'/'%' unit are *100; per-unit KPIs are a raw quotient."""
    tree = (bm or {}).get("kpi_tree", [])
    ue = (bm or {}).get("unit_economics", {})
    resolved = 0
    for k in tree:
        if not k.get("computable", True):
            continue
        ins = k.get("inputs") or []
        if len(ins) != 2:
            continue
        kpi = k.get("kpi") or "kpi"
        unit = (k.get("unit") or "").lower()
        as_pct = ("%" in unit) or ("pct" in unit) or ("percent" in unit)
        for basis in st.bases():
            for kind in ("FY", "Q"):
                for period in st.periods(basis, kind):
                    n = st.get_exact(ins[0], period, basis)
                    d = st.get_exact(ins[1], period, basis)
                    nv, nid = n if n[0] is not None else st.find(norm(ins[0]), period=period, basis=basis)[:2]
                    dv, did = d if d[0] is not None else st.find(norm(ins[1]), period=period, basis=basis)[:2]
                    if nv is not None and dv:
                        val = nv / dv * (100 if as_pct else 1)
                        em.emit(kpi, period, basis, val, k.get("unit") or ("pct" if as_pct else "ratio"),
                                f"{ins[0]} / {ins[1]}" + (" * 100" if as_pct else ""), [nid, did])
                        resolved += 1
        if resolved == 0:
            em.skip(f"kpi_tree '{kpi}': inputs {ins} did not resolve in any period")
    return resolved


# ---- rendering --------------------------------------------------------------------------
def render_md(em, ticker):
    """Group KPI facts into trend tables: one table per basis, metric rows x period columns,
    FY first then quarters, with a trailing YoY column on FY tables."""
    by_basis = {}
    for f in em.facts:
        by_basis.setdefault(f["basis"], []).append(f)
    out = [f"# {ticker} — operating KPI trends", "",
           "*Computed by tools/compute_kpis.py from extracted volume/segment facts. "
           "Interpretation (why a KPI moved) is the analyst's job — this is the data, not the read.*", ""]
    for basis in sorted(by_basis):
        rows = by_basis[basis]
        metrics = sorted({r["metric"] for r in rows})
        fys = sorted({r["period"] for r in rows if r["period_type"] == "FY"})
        qs = sorted({r["period"] for r in rows if r["period_type"] == "Q"})
        cols = fys + qs
        if not cols:
            continue
        out.append(f"## {basis.title()} — {len(metrics)} KPIs x {len(cols)} periods")
        out.append("")
        header = ["KPI", "unit"] + cols + (["YoY (last FY)"] if len(fys) >= 2 else [])
        out.append("| " + " | ".join(header) + " |")
        out.append("|" + "---|" * len(header))
        idx = {(r["metric"], r["period"]): r for r in rows}
        for m in metrics:
            unit = next((r["unit"] for r in rows if r["metric"] == m), "")
            cells = []
            for c in cols:
                r = idx.get((m, c))
                cells.append(f"{r['value']:.2f}" if r else "—")
            yoy = ""
            if len(fys) >= 2:
                a = idx.get((m, fys[-2])); b = idx.get((m, fys[-1]))
                if a and b and a["value"]:
                    yoy = f"{(b['value']/a['value']-1)*100:+.1f}%"
            row = [m, unit] + cells + ([yoy] if len(fys) >= 2 else [])
            out.append("| " + " | ".join(row) + " |")
        out.append("")
    return "\n".join(out) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("facts_file")
    ap.add_argument("--out", required=True)
    ap.add_argument("--out-md", required=True)
    ap.add_argument("--business-model", default=None)
    ap.add_argument("--ticker", default="TICKER")
    a = ap.parse_args()

    data = json.loads(Path(a.facts_file).read_text(encoding="utf-8"))
    facts = data["facts"] if isinstance(data, dict) else data
    st = FactStore(facts)
    em = Emitter()

    bm = None
    if a.business_model and Path(a.business_model).exists():
        bm = json.loads(Path(a.business_model).read_text(encoding="utf-8"))
    n_tree = tree_kpis(st, em, bm) if bm else 0
    # always also run the library (it fills what the tree missed; dedup is by (metric,period,basis))
    seen = {(f["metric"], f["period"], f["basis"]) for f in em.facts}
    before = len(em.facts)
    library_kpis(st, em)
    em.facts = ([f for i, f in enumerate(em.facts) if i < before]
                + [f for f in em.facts[before:] if (f["metric"], f["period"], f["basis"]) not in seen])

    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    Path(a.out).write_text(json.dumps({"facts": em.facts, "skipped": em.skipped}, indent=2, ensure_ascii=False),
                           encoding="utf-8")
    Path(a.out_md).parent.mkdir(parents=True, exist_ok=True)
    Path(a.out_md).write_text(render_md(em, a.ticker), encoding="utf-8")

    print(f"OK: {len(em.facts)} KPI facts ({n_tree} from business-model tree, rest from library) "
          f"-> {a.out}; trends -> {a.out_md}; {len(em.skipped)} unresolved (see out file)")


if __name__ == "__main__":
    main()
