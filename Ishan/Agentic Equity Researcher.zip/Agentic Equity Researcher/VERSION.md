# Agentic Equity Researcher — Version

## v2.0 — 2026-07-13
- Optional buy-side stage: buy-side-analyst agent + prompts/60_buy_side.md (self-contained EPS-bridge doctrine), NOT in default lifecycle
- EPS-bridge deterministic checker (tools/eps_bridge_check.py) + Excel export (tools/export_financials_xlsx.py)
- equity-research-formatter skill + tools/report_formatter/ Node engine → styled .docx FORMAT stage (step 9)
- prompts/03_business_model_and_value_chain.md, prompts/70_sparse_data_playbook.md, tools/compute_kpis.py (operating-KPI trends + unit economics)

## v1.1 — 2026-07-08 (retrofit)
- markitdown CONVERT step (0.5), comprehensive statement builder, level-3 note depth, quarterly seasonality, role groupings

## v1.0 — initial
- Staged pipeline (prompts 00-50), 11 subagents, JSON fact schemas, one citation standard, circular orchestration

## Sync policy
Standalone project is upstream for research logic. Fund copy (research/equity_researcher/) regenerates sector_packs and config/eps_bridge_thresholds.yaml from the fund registry; the fund-level buy_side agent (cycle-aware) is canonical under the fund. Sync is manual and deliberate.
