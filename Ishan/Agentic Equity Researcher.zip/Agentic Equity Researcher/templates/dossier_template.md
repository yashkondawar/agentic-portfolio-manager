<!-- Dossier skeleton — full spec in prompts/40_dossier_assembly.md. Anti-compression: complete tables, complete ledgers. -->

# {Company} ({TICKER}) — Research Dossier (full audit document)
*Run date: {date} · Inputs: {n} documents (manifest below) · Basis: {consolidated/standalone} (reason: {…})*

## 0. Input manifest & run record
{table: file | classification | period | pages | notes} · {run_log summary: waves dispatched, loops used, why order varied}

## 1. Executive summary
{Thesis, financial health, valuation synopsis, top 4 risks. No rating here — rating lives only in the final note.}

## 2. Industry & market analysis
{DR2 in full: value chain & bottleneck · Porter's 0–10 with justifications · TAM build · cycle-overlap checks · policy architecture}

## 3. Company deep-dive
{Segments & mix evolution · unit economics & cost buckets · moat matrix with evidence · competitive positioning}

## 4. Historical financial performance
{All years IS/BS/CF rendered tables · adjusted margins · ROCE trajectory · capex & incremental returns · working capital · why-why on every >threshold margin move}

## 5. Management & governance
{Leadership table · guidance ledger + credibility · direct-quotes bank (claims vs reality) · forensic scorecard /100 · chronology · shareholding & pledge trend}

## 6. Earnings quality & red-flag ledger (complete)
{Every flag: id | category | status | severity | why-chain | management story | confidence. Dismissed flags stay visible with reasons.}

## 7. Valuation & peers
{Historical multiple bands · full peer tables (domestic + international, comparability deltas) · premium/discount analysis · what's-priced-in · insights table}

## 8. Estimates (full build)
{Driver tree · assumption ledger rendered · sanity gates shown · scenarios · variant view}

## 9. Future outlook & monitorables
{Sector-pack checkpoints · catalyst calendar · what-would-change-the-view}

## 10. Risk factors
{Industry / operational / financial / governance — probability-impact + mitigants}

## 11. Concluding synthesis
{Strengths vs vulnerabilities; ≤1 structural metaphor; no new facts}

## 12. Annexure (verbatim, unabridged)
{Complete standalone & consolidated statements · horizontal/vertical analysis · FCF calculations · all ratio tables}

## 13. Global source legend
{Every SRC id → original source; generated from registry; deduplicated}

## 14. Open questions & gaps register
{Every question: status, answer ref or disclosure}

---
{templates/disclaimer.md verbatim}
