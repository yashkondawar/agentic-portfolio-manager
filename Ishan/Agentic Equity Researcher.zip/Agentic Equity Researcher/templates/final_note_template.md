<!-- Final Note skeleton — spec in prompts/41_final_report.md. Placeholders in {braces}. -->

# {Company Name} ({TICKER}) — Initiating Coverage

| **{RATING}** | {One-line thesis} |
|---|---|
| **Fair-value context** | {range} — indicative band (5y fwd-PE band × FY+2E EPS); formal TP pending scenario engine (see handoff) |

*The rating above is the only recommendation statement in this note.*

**Snapshot** *(as of {date})*

| CMP | Mcap (₹ cr) | 52-wk H/L | Promoter % (pledge) | FII / DII % | Free float | Fwd P/E FY+1E / FY+2E |
|---|---|---|---|---|---|---|
| {} [S] | {} [S] | {} [S] | {} [S] | {} [S] | {} [S] | {} / {} [S] |

## Investment thesis
{3–4 pillars. One paragraph each, ≥2 evidence refs per pillar. Plain analytical voice.}

## Variant view & what's priced in
{Where we differ from guidance/consensus and why. Reverse-multiple read: "CMP implies ~X% EPS CAGR at constant multiple Y×."}
**Top 4 risks:** {one line each, probability–impact tagged}

## Company
{What the business is; segment mix table + evolution; the 2–3 structural facts that matter.}

## Industry & competition
{Market-size build with numbers; quantified growth drivers; value-chain bottleneck and who owns it; cycle position.}

**Exhibit — Peer comparison** *(decision-relevant cut)*
{table: growth | margins | ROCE | leverage | P/E | sector KPI — with premium/discount verdict below}

## Financial analysis
**Exhibit — Financial summary** {multi-year rendered table}
{The 3–4 findings that drive the thesis: margin architecture · capex→incremental ROCE · working capital/cash conversion · funding. Each why-chain compressed to 2–3 sentences.}

## Earnings quality & governance
{Earnings-quality score /100 with drivers; governance verdict (Green/Amber/Red) + score; confirmed high-severity flags; count of checks passed/dismissed; guidance credibility summary.}

## Estimates & valuation
**Exhibit — Estimates** {FY-2A … FY+2E table: revenue, growth %, EBITDA, margin %, PAT, EPS, ROE, capex, FCF, P/E@CMP}
{5 assumptions that matter, each with basis. Forward P/E vs 5y band vs peers.}
**Scenarios (inputs to downstream PT engine — not price targets):** base / bull / bear EPS CAGR + one-line rationale each.

## Risks, catalysts & monitorables
{Risks with mitigants · dated catalyst calendar · monitorables with the threshold that would change the view.}

## Data gaps & limitations
{Unanswered high-severity questions (disclosed) · verification UNVERIFIABLEs · missing documents.}

---
{Disclaimer + AI-use disclosure — templates/disclaimer.md verbatim}
*Full audit trail: dossier.md · machine-readable estimates: handoff/valuation_handoff.json*
