# Agentic Equity Researcher (v1)

A sell-side equity research agent for India-listed companies, built to run **natively in Claude Code**: open this folder in Claude Code and the orchestrator playbook (`CLAUDE.md`) takes over. It produces an initiation-style research note (≤12 pages), a full audit dossier, and a machine-readable handoff for a downstream valuation/sensitivity agent (PE re-rate/de-rate/constant → target price — future iteration).

## Quickstart (native mode — default)

1. Drop company documents into `input/<TICKER>/` (see `input/README.md` for the ideal set and naming).
2. Open Claude Code in this folder and say: **"Initiate coverage on `<TICKER>` (`TICKER.NS`)"** — include the yfinance symbol so market data resolves.
3. The orchestrator runs intake → triage → parallel extraction → deterministic ratios → analysis waves → deep research loops → estimates → verification → report. Progress and every scheduling decision land in `workspace/<TICKER>/state/run_log.md`.
4. Outputs in `workspace/<TICKER>/`:
   - `report/final_note.md` — the ≤12-page note (rating once, at top)
   - `report/dossier.md` — long-form audit document with global source legend
   - `handoff/valuation_handoff.json` — contract for the next agent (see `templates/valuation_handoff.example.json`)

You can steer mid-run like a real desk head: "dig deeper into the capex plan", "add peer X", "re-check receivables" — the circular protocol absorbs new work and updates dependent findings rather than restarting.

## What it does (and deliberately doesn't)

- **Does**: two-tier financial extraction with page-level audit trail; deterministic ratio/flag computation; forensic earnings-quality review; management-guidance credibility scoring; governance/promoter checks (India-specific); web deep research (company DR1 + sector/peers DR2 with sector KPI packs); drivers-based FY+1/FY+2 estimates; forward-PE positioning; adversarial citation verification.
- **Doesn't (v1, by design)**: DCF/WACC, ESG section (config toggles for later); formal target price (that's the downstream agent's job — this agent ships the scenario seeds and PE bands it needs); chart images (tables only in v1).

## The circular part

This is not a linear pipeline. State lives in a shared dossier (`facts/`, `findings/`, `state/`); every finding declares what it depends on; new information (a research answer, a restatement, a contradiction) marks dependent findings stale, and **only those** re-run. Order varies per company via rule-based triage (`prompts/02`) — a pure-play launches sector research immediately in parallel; a multi-segment story extracts financials first, then branches research per segment. The *reason* for every ordering decision is logged. Full protocol: `prompts/01_orchestration_protocol.md`.

## Repo map

```
CLAUDE.md                 orchestrator playbook (the agent's brain in native mode)
config/agent_config.yaml  rating scale, page budget, thresholds, model tiers, loops
prompts/                  module prompts 00-50 (single source of truth for subagents)
prompts/sector_packs/     BFSI, consumer, commodities, IT, pharma, auto, infra, generic
.claude/agents/           11 subagents (haiku extraction / sonnet analysis / opus writing)
schema/                   fact record, open question, red flag, valuation handoff
tools/                    deterministic Python: market_data, merge_facts, compute_ratios,
                          render_tables, citation_check   (all smoke-tested)
templates/                final note, dossier, disclaimer, handoff example
input/<TICKER>/           your documents go here
workspace/<TICKER>/       run state + outputs (created per run)
reference/                extracted copies of the three source design documents
api_mode/                 optional API/SDK runner (NOT the default; see its README)
docs/DESIGN_DECISIONS.md  what changed vs the original prompt set, and why
```

## Requirements

Python 3.10+ with `yfinance` and `pandas` (`pip install -r tools/requirements.txt`; already present on this machine). Web access for deep research (degrades gracefully to document-only with disclosed gaps).

## Iteration-1 limits & next steps

No consensus-estimates feed (variant view is vs. guidance); charts are tables; docx/PDF rendering of the note is a later step; the benchmark harness (compare output against a real initiation note) is the recommended next build. See `docs/DESIGN_DECISIONS.md` §Roadmap.
