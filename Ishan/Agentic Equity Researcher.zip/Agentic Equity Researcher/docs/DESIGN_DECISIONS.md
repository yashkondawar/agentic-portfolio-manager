# Design Decisions — what changed vs. the source documents, and why

The three source documents (extracted copies in `reference/source_documents/`) were treated as a starting point, per the brief. This file records every material deviation so they're arguable rather than silent.

## Conflicts resolved

| # | Conflict | Resolution |
|---|---|---|
| 1 | Architecture doc mandates a **≤12-page** report; Reports_generation_prompt mandates **20–22 pages / 8–10k words** | Both ship: the 20-22p+ spec became the **dossier** (full audit doc, anti-compression); the ≤12p spec became the **final note**. The original user text actually asked for exactly this pair ("a long appended doc with all auditable traceable format, and finally an equity research report… not more than 12 pages"). |
| 2 | Reports_generation_prompt contains company-specific residue (Depository/KRA/Repository segments, T+0 settlement, Insurance Demat, "Digital Toll Bridge") — it was written against a CDSL-type company | Generalized: structure parameterized, sector specifics now come from the sector pack + triage; the metaphor rule became "≤1 structural metaphor, no new facts". |
| 3 | Every prompt demanded "Markdown tables ONLY" as the working format; the architecture doc itself argues for JSON records with markdown only at render | Sided with the architecture doc: JSON fact records everywhere internally (`schema/fact_record.schema.json`), markdown rendered deterministically at the end (`tools/render_tables.py`). Parsing your own markdown back to merge 16 documents is strictly worse. |
| 4 | Fin_analysis_prompt1 and Fin_analysis_prompt2 overlap (both do CFO/NI reconciliation, DSO, receivable flags) with no shared context — they could emit contradictory versions of the same flag | Single shared red-flag ledger (`schema/red_flag.schema.json`). Deterministic thresholds seed candidates; **forensic adjudicates all verdicts**; fundamental only enriches. No private flag lists. |
| 5 | Prompts asked the LLM to do arithmetic "digit-by-digit" | All standard ratios/growth/thresholds moved to `tools/compute_ratios.py` (zero tokens, zero arithmetic hallucination). Audit trail preserved via `formula` + `inputs` on every derived record. LLM computes only what a script can't, and must show work. |
| 6 | DR1 "Task 5,6,7" asked deep research to web-find prices/mcap/index returns | `tools/market_data.py` (yfinance) — deterministic, timestamped, exact. Deep research is barred from price-finding except as flagged last-resort. (Architecture doc's own recommendation.) |
| 7 | Eight slightly different audit-trail instructions ("supersede all other context…") across prompts | One `prompts/00_citation_standard.md` that genuinely supersedes; all module prompts reference it. Global source registry with namespaced ids replaces per-prompt legend conventions ([FN1]/[FA2.1]/[TT1.1] → SRC-###/[S#]). |
| 8 | "Buy-side practical" framing in DR2 prompt family vs the stated goal of a **sell-side** agent | Tone kept analytical; deliverable reframed sell-side: rating box (once), thesis pillars, variant view, estimates table, catalysts/monitorables. Rating scale BUY/ADD/REDUCE/SELL (config). |
| 9 | "IQ above 160" style roleplay in analysis prompts | Removed. Replaced with concrete procedures (what to check, what evidence adjudicates, what to output). Roleplay doesn't improve extraction; explicit method does. |
| 10 | Original FCF definition included "purchase of investments" in capex | Excluded financial-investment purchases from net capex (treasury churn isn't capex; including it breaks FCF for cash-rich companies). Deviation noted in the tool docstring; treasury behaviour still analyzed under other-income dependence. |

## Additions (gaps vs. real sell-side practice — the "critique and add more" ask)

1. **Verification wave** (`prompts/50` + citation-auditor + `tools/citation_check.py`): every prompt asserted an audit trail; nothing checked it. An invented page number is as easy as an invented revenue figure. Adversarial re-derivation, default-refute, load-bearing = 100%.
2. **Estimates module** (`prompts/32`): the source set analyzed history but produced no forward numbers — yet the stated goal needs FY+1/FY+2 projections, forward PE, and a handoff for PE-scenario sensitivity. Drivers-based build with credibility-weighted guidance, sanity gates, scenario seeds.
3. **Guidance credibility tracker** (in `prompts/22`): guidance-vs-delivery history scored per metric family. Sell-side lives and dies on knowing whose guidance to believe; nothing in the source prompts tested it.
4. **Capex/returns engine depth** (in `prompts/20`): incremental ROCE, gross-block→revenue conversion lag, CWIP ageing → commissioning slippage. The brief explicitly emphasized capex; the source prompts only had "CAPEX/CFO spike" as a fraud screen.
5. **Coverage snapshot block + variant view + what's-priced-in + catalysts calendar** (in `prompts/41`): the architecture doc's own critique listed these as the gap between "checklist" and a real initiation note.
6. **Rule-based triage** (`prompts/02`): makes "dynamic, not a flow" auditable — the order varies, but the rule that fired is logged.
7. **Staleness propagation** (`prompts/01` §2): `depends_on`/`impacts` machinery so late research updates exactly the findings built on the old gap — the user's "circle back to the start" requirement, without re-running everything.
8. **BFSI structural fork**: lender financials aren't manufacturing financials; extraction addendum + pack + graceful ratio skipping.
9. **Failure isolation**: per-wave cache keys, retry-once, degrade-to-gap — from the architecture doc's journaling advice.

## Removals / demotions

- **Fin_processing_prompt** as an LLM step — replaced by `compute_ratios.py`; its "no re-calculation, reported wins" rule survives in the citation standard §2.
- **ESG and DCF/WACC** — excluded per explicit instruction; config toggles left in place.
- **"Recommendation only once"** — enforced structurally (template has exactly one rating box; report prompt bans restatement).
- Boolean search strings, NSE URL patterns, cycle-check framework, sector KPI menus — **kept** (they're the domain value of the source docs), reorganized into `prompts/30/31` + sector packs with the 8× repeated boilerplate deduplicated.

## Defaults chosen (change in `config/agent_config.yaml`)

Rating scale BUY/ADD/REDUCE/SELL · markdown deliverables (docx render is roadmap) · consolidated basis preferred when subs material · research loops max 3 · verification sample 30% (load-bearing 100%) · fair-value context only, no TP (downstream agent owns TP).

## Roadmap (post-v1)

1. **Valuation/sensitivity agent** consuming `valuation_handoff.json` → PE re-rate/de-rate/constant grid → TP; then the note's rating box gets a real TP.
2. **Benchmark harness**: run against a company with a real published initiation note; diff section-by-section (the user's stated evaluation plan).
3. Chart rendering (matplotlib → PNG exhibits), docx/PDF export of the final note.
4. Consensus-estimates source (variant view vs street, not only vs guidance).
5. api_mode hardening: docling+langextract extraction with character-offset grounding for the verification wave (span-level, beyond page-level).

## 2026-07-08 — Numbers-depth retrofit

A gap analysis against real sell-side practice ("3 levels deep through all
notes, one comprehensive statement") specified five changes, executed as a
single retrofit:

1. **markitdown preprocessing (step 0.5 CONVERT)**: `tools/convert_docs.py`
   runs deterministically before extraction — page-anchored markdown
   (`cache/markdown/<docid>.md`, via pypdf page-split + markitdown per page,
   since markitdown alone collapses page boundaries on a whole multi-page
   PDF) and per-page table JSON with bbox metadata
   (`cache/tables/<docid>_p<N>_t<K>.json`). Zero tokens; haiku extractors now
   read structured text/tables instead of raw PDF layout. Original PDFs in
   `input/<TICKER>/` are never modified — the caches are derived, and the
   citation-verification wave still grounds against the original PDF page.
2. **Level-3 extraction trigger** (`prompts/10`): extraction no longer stops
   at the first note breakdown — a Level-2 note with its own sub-schedule
   (borrowings by instrument and maturity, ageing buckets, RPT by
   counterparty) now emits Level-3 records. Paired with an explicit
   instruction to exclude one-off items from the FCF calculation and
   disclose the exclusion in `flags`.
3. **Comprehensive statement** (`tools/build_comprehensive_statement.py`,
   new COMPUTE-step tool, zero tokens): assembles
   `state/comprehensive_statement.{json,md}` — a line-item TREE (level 1→2→3)
   per statement (IS/BS/CF) x all fiscal years and available quarters, each
   node carrying its fact_ids. This is the "one comprehensive statement" the
   original ask named; `prompts/20`/`32` now anchor line-item analysis and
   driver decomposition to its nodes, and the dossier (`prompts/40`) renders
   it (full, or top-2-level summary if it would blow the anti-compression
   budget).
4. **Quarterly trend & seasonality** (`prompts/20`, new item): QoQ/YoY-by-quarter
   view of revenue/margins/working-capital from Q/H facts, flagging any
   quarter where the annual narrative and quarterly cadence disagree — a gap
   the original module set didn't cover (annual-only trend analysis).
5. **Role groupings** (`CLAUDE.md`, `config/agent_config.yaml`): a purely
   descriptive mapping from the user's own staging vocabulary (DEX/QFA/
   IGL/CRA/BSA) onto this system's numbered modules, plus an explicit
   "Combined all" note (the `workspace/<TICKER>/` state, centered on
   `state/comprehensive_statement.json`, IS the combined-all artifact — no
   separate mega-file) and an orientation line making explicit that this
   system's center of gravity is equity research and numbers depth, not
   forensic earnings-quality (21 is one module in that flow).

No behavior changed for existing modules beyond the specific insertions
above; no ticker run exists yet to validate end-to-end (no documents in
`input/<TICKER>/` at time of writing) — `convert_docs.py` and
`build_comprehensive_statement.py` were validated against ad hoc fixtures
(a real multi-page PDF for conversion; a synthetic 3-level/2-period fact set
for the statement tree) instead.

## 2026-07-13 — Buy-side EPS-bridge stage added (optional, non-default)

Ported from the fund repo (`D:\Documents\Claude\1Projects\AI Native Fund`),
where the user supplied a buy-side EPS-bridge doctrine (Price = EPS × PE;
consistent >20% EPS growth + low starting PE → rerating; six-rung
decomposition from revenue visibility down to EPS; funding-discipline and
working-capital rules; a qualitative management-intent gate) and it was
first encoded there as `knowledge/references/methodology/eps_bridge.md` +
`registry/rules/eps_bridge.yaml` + `research/equity_researcher/tools/
eps_bridge_check.py` + `.claude/agents/buy_side.md`. This project received
the standalone half of that work:

1. **Added, not wired into the default pipeline.** `.claude/agents/
   buy-side-analyst.md` (opus tier, `tools: Read`) and `prompts/
   60_buy_side.md` exist alongside the 0→8 run lifecycle but are not
   dispatched by any wave in `prompts/01_orchestration_protocol.md`. They
   run only when the user explicitly asks for the buy-side analysis, against
   a ticker that already has a completed run. `CLAUDE.md` gained a short
   "Optional buy-side stage" section saying exactly this; the orchestration
   protocol file only gained COMPUTE-step wiring notes (see below), not a
   dispatch entry — a deliberate scope boundary from the source plan.
2. **Two deterministic tools ported into `tools/`**: `eps_bridge_check.py`
   (reads the merged facts store, computes PASS/FAIL/NA + numbers per
   EPS-bridge rule, zero tokens) and `export_financials_xlsx.py` (openpyxl
   export of the comprehensive-statement tree + ratios + checker output +
   red-flag ledger to `exports/<TICKER>_financials.xlsx`). Both are wired
   into the COMPUTE step (`CLAUDE.md` step 3, after
   `build_comprehensive_statement.py` has written
   `state/comprehensive_statement.json`) alongside the existing
   `compute_ratios.py` / `build_comprehensive_statement.py` pair.
   `export_financials_xlsx.py` needed no changes at all (it already had no
   fund imports). `requirements.txt` gained `openpyxl` and `pyyaml`.
3. **Thresholds inlined locally, not shared via a registry.** This project
   has no `registry/` layer (that's a fund-only concept), so
   `eps_bridge_check.py`'s threshold loader was adapted: it now resolves
   thresholds from an explicit `--thresholds` file if given, else
   auto-discovers `config/eps_bridge_thresholds.yaml` (new file, an inlined
   copy of the fund's `registry/rules/eps_bridge.yaml` values — same DRAFT
   status markers, same `sector_overrides: {}` block, same threshold
   values), else falls back to the same `DEFAULT_THRESHOLDS` constant the
   fund copy already carried for standalone-safety. The YAML-vs-JSON
   `{value, status, note}` block shape is flattened by a small loader
   helper (`_load_thresholds_file`) that didn't exist in the fund version
   (which only ever read a flat JSON override file).
4. **Deliberate duplicate of the doctrine text.** `prompts/60_buy_side.md`
   embeds the full EPS-bridge doctrine prose (adapted from the fund's
   `knowledge/references/methodology/eps_bridge.md` — its pointers to the
   fund's `buyside_depth.md` companion methodology and
   `knowledge/references/sectors/<sector>.md` sector-override files were
   removed or rewritten, since neither exists in this project; the
   management-track-record pointer was redirected to this project's own
   module 22 guidance-credibility ledger instead) plus the reasoning ladder
   and output contract, so the standalone project stays self-contained (no
   fund pointer). This is a second copy of that text by design — keeping it
   in sync with the fund's version if the doctrine changes is a manual,
   human-driven step, not automated. `.claude/agents/buy-side-analyst.md`
   was written in this project's own agent style (plain role-mandate prose,
   "On start, read" list, JSON-only output contract) rather than copying the
   fund's SECURITY-preamble agent format, since none of this project's
   existing 11 subagents use that preamble style.
5. **Sanity-checked, not run end-to-end.** Both ported tools were verified
   with `ast.parse` and `--help` (fund venv Python) and
   `eps_bridge_check.py` was smoke-tested against a small synthetic
   `financials.json` fixture to confirm the local YAML threshold
   auto-discovery resolves correctly. No ticker in this project has a
   completed run yet, so the buy-side agent itself has not been invoked
   end-to-end — same honesty posture as the rest of this file's prior
   entries.
