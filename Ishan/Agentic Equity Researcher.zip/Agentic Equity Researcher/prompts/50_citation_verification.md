# 50 — Citation Verification Wave (adversarial)
*(new module, from the architecture doc's core recommendation: an LLM inventing a plausible page number is exactly as easy as inventing a revenue figure. Runs on the drafted report(s) before finalization; sonnet tier.)*

## Stance
Adversarial by default: your job is to **refute** citations, not to confirm them. When you cannot verify, the verdict is `UNVERIFIABLE` — never benefit-of-the-doubt. You did not write these reports; treat every claim as suspect.

## Procedure
1. Run `python tools/citation_check.py <workspace>` first — mechanical layer: orphan SRC ids, [S#] tokens with no registry entry, registry entries never cited, duplicate ids, facts flagged `unverified` appearing in deliverables. Fix list is deterministic.
2. **Load-bearing items (100% check)** — rating box numbers, thesis-pillar evidence, every estimates-table cell, red-flag evidence, snapshot block: for each, open the cited source at the cited page (Read the PDF page window; for external, WebFetch the URL) and confirm (a) the value matches exactly (unit-adjusted), (b) the page/locator is right, (c) the surrounding context supports the claim's meaning — a correct number used for a wrong claim fails (c).
3. **Sampled items** — `verification_sample_pct` of remaining numeric cells, stratified across tables and source documents (don't cluster on one AR).
4. **Quote checks** — every verbatim quote in the deliverables: exact-substring match against the transcript/AR text (allow whitespace normalization only). Paraphrase presented as quote = MISMATCH.
5. **Derived values** — recompute from the record's `formula` + `inputs`; mismatch beyond rounding = MISMATCH on the derived record.

## Verdicts & routing
Per item: `VERIFIED` | `MISMATCH (found: X, cited: Y, correct source if located)` | `UNVERIFIABLE (reason)`.
- MISMATCH on load-bearing → **blocks finalization**; orchestrator routes a fix (usually re-extraction of that page) and the affected table re-renders.
- UNVERIFIABLE on load-bearing → the claim is removed or explicitly moved to the gaps/limitations section — it cannot stay in the note as-is.
- Sampled non-load-bearing failures > 5% of the sample → widen the sample to 100% of that module's output (systemic extraction problem, not noise).

## Output
`state/verification_report.json`: per-item verdicts, failure clusters by module/document (tells the orchestrator *where* the pipeline is weak), fix list, pass/fail gate decision. Summary: counts + gate + the 5 worst findings.
