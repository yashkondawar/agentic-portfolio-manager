# Sector Pack — Pharma & Chemicals (generics, APIs, CDMO/CRAMS, specialty chem, agrochem)
*Shared rules live in prompts/31.*

**Core truth:** commodity generics erode; value accrues to complexity (injectables, biosimilars, validated specialty molecules) and to compliance track record. NPPA/NLEM caps the domestic price umbrella; USFDA status caps the US one.

## Qualitative lenses
- **Complexity moat**: mix shift toward complex generics/injectables/biosimilars; CDMO/CRAMS depth (client validation cycles = switching costs).
- **Backward integration**: KSM/API self-sufficiency %, PLI benefit capture, China-dependence of inputs.
- **Compliance**: USFDA/EDQM/DCGI history per facility (warning letters, import alerts, OAI/VAI), revenue at risk per facility, remediation credibility.
- **Pipeline**: ANDA stock/flow, Para-IV filings and success rate, first-to-file value; for specialty chem — molecules under multi-year contracts, patents cliff calendar of clients.
- **China+1**: evidenced share shifts in CDMO/API sourcing (not just narrative).
- **Domestic**: NLEM exposure % of revenue, chronic vs acute mix, MR productivity.
- **US generics**: price-erosion rate trend by peer commentary.

## KPI table rows (target + peers)
| Category | KPIs |
|---|---|
| Valuation | price date, mcap, EV, P/E (LTM), forward P/E, EV/EBITDA |
| Profitability | revenue, EBITDA, PAT (ex one-offs), GM %, EBITDA %, ROCE %, ROE % |
| Balance sheet | net debt/EBITDA, capex, R&D % of sales |
| Growth | revenue growth %, expected growth %, US/domestic/CDMO growth split |
| Mix | US generics %, domestic formulations %, CDMO/CRAMS %, specialty % |
| Integration | API/KSM in-house % (if quantifiable) |
| Pipeline | ANDA filings/approvals (annual), Para-IV pending, facility compliance status |
| Cash | CFO, FCF, FCF yield %, FCF/EBITDA % |

**Relative-valuation justifier:** premium vs compliance cleanliness + high-margin mix (CDMO/specialty share) + pipeline optionality — a clean-facility CDMO deserves different math than a commodity-generic exporter; never blend them silently.

**Preferred sources:** USFDA inspection classification database, company facility disclosures, NPPA/NLEM lists, PLI notifications, IQVIA citations for domestic market shares.
