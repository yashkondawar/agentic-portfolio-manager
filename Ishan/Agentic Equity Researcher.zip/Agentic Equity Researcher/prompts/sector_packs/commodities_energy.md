# Sector Pack — Commodities & Energy (metals, cement, oil & gas, power, CGD)
*Shared rules live in prompts/31.*

**Core truth:** players are price-takers; the only durable edge is cost-curve position. Analyze the spread (realization − cost), not the price.

## Qualitative lenses
- **Cost-curve position**: global quartile; what creates it (ore/coal captivity, energy mix, logistics, scale) and its durability.
- **Integration**: captive mines/power quantified as ₹/unit advantage vs peers; upstream/downstream balance.
- **Capital allocation**: peak-cycle behaviour — debt paydown vs expansion vs buybacks; count of cycle-top acquisitions in history (imprudence marker).
- **Trade policy moat**: anti-dumping/safeguard duties, import parity dynamics, their expiry/renewal risk.
- **Demand linkage**: government capex/NIP for cement & steel; PPA terms and counterparty (SEB) quality for power; APM allocation vs market gas for CGD; Brent/cess sensitivity for upstream.
- **Cement specifically**: freight makes it hyper-local — regional pricing power, lead distances, clinker/grinding balance.
- **ESG/cost risk**: carbon-tax exposure, pollution-norm capex ahead.

## KPI table rows (target + peers)
| Category | KPIs |
|---|---|
| Valuation | price date, mcap, EV, P/E (LTM), forward P/E, EV/EBITDA |
| Profitability | revenue, EBITDA, PAT (ex one-offs), GM %, EBITDA %, ROCE %, ROE % |
| Unit economics | **EBITDA/tonne (or /unit/barrel/scm)**, cost of production/unit, realization/unit, spread/unit |
| Balance sheet | net debt, net debt/EBITDA, interest coverage, capex |
| Growth | revenue growth %, volume growth %, capacity utilization % |
| Integration | captive power % of consumption, captive RM % |
| Cash | CFO, FCF post-dividend, FCF yield %, dividend payout %, FCF/EBITDA % |
| O&G (if applicable) | realization/bbl or /MMBtu, E&D spend % of revenue, reserve replacement |

**Relative-valuation justifier:** EV/EBITDA and P/B vs cost-curve position (EBITDA/unit) and balance-sheet discipline (net debt/EBITDA) — mid-cycle multiples on mid-cycle earnings, never peak-on-peak.

**Preferred sources:** exchange filings, PPAC/CEA/JPC industry stats, global price indices (LME, Platts citations), company cost walks in decks.
