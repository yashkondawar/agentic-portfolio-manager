# Sector Pack — Generic (fallback for unclassified / conglomerate / niche sectors)
*Shared rules live in prompts/31. Use when no specialized pack fits; borrow rows from the closest pack for any sub-segment.*

**First job:** figure out what kind of business this economically is — asset-heavy price-taker? brand/distribution compounder? contract/order-book executor? regulated utility? platform/network? — then apply the matching lenses and steal the KPI rows from the corresponding pack. State the classification and why.

## Qualitative lenses
- **Competitive differentiation**: supply-chain/sourcing edges, proprietary tech, distribution (incl. Tier-2/3 penetration), regulatory positioning per key peer vs target.
- **Industry voice**: what competitor managements say about the industry's direction (latest transcripts/decks, tone noted).
- **Moat (India-specific)**: regulatory (PLI, licensing, tariffs) vs distribution vs switching-cost moats; sustainability of each.
- **Industry economics**: demand drivers (macro/demographic/policy) with data; pricing determinants (inputs, FX, tariffs); pass-through vs operating-leverage character; sensitivity estimates.
- **Headwinds/tailwinds**: 3–5 recent (≤6 months) credible forecasts; leading indicators relevant to the sector (PMI, freight, credit growth, etc.).
- **India risk overlay**: electoral/policy exposure, government-counterparty receivables.

## KPI table rows (target + peers)
| Category | KPIs |
|---|---|
| Valuation | price date, mcap, EV, P/E (LTM), forward P/E, EV/EBITDA, P/B, FCF yield % |
| Profitability | revenue, EBITDA, PAT (ex one-offs), EPS diluted, GM %, EBITDA %, PAT %, ROCE %, ROE % |
| Balance sheet | net debt, D/E, net debt/EBITDA, order book (if applicable) |
| Growth | revenue growth %, profit growth %, expected growth % |
| Cash | CFO, capex, FCF pre/post dividend, FCF/EBITDA conversion % |
| Sector-specific | **find ≥3 KPIs the industry itself tracks** (ARPU, SSSG, EBITDA/tonne, occupancy, realization/unit…) — from company decks and industry reports; define each |

**Relative-valuation justifier:** cheapness/expensiveness vs ROCE stability and leverage — explain the multiple gap or flag it unexplained (unexplained gaps are findings, not conclusions).
