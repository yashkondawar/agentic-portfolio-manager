# Sector Pack — Consumer & Retail (FMCG, discretionary, durables, QSR, liquor)
*Shared rules live in prompts/31.*

**Core truth:** the moat is distribution + brand; the P&L tell is gross-margin stability through input cycles (pricing power) and the split of growth between volume and premiumization.

## Qualitative lenses
- **Pricing power**: GM expansion/hold through commodity cycles; price-hike absorption evidence; elasticity by category.
- **Distribution moat**: rural reach, direct-coverage outlets, last-mile efficiency; Q-commerce/DTC success and cannibalization risk vs GT/MT.
- **Volume vs premiumization**: which is driving value growth per peer; new-category success rates.
- **Monsoon & rural**: correlate FMCG peer sales with monsoon/MSP/farm-income data where the mix is rural-heavy.
- **Rivalry read**: A&P intensity trend, discounting behaviour, private-label/D2C insurgent pressure.
- **Niche**: QSR — SSSG trend and store payback; durables — housing/retail linkage, channel inventory; liquor — state pricing/tax regimes and route-to-market changes.

## KPI table rows (target + peers)
| Category | KPIs |
|---|---|
| Valuation | price date, mcap, EV, P/E (LTM), forward P/E, EV/EBITDA |
| Profitability | revenue, EBITDA, PAT (ex one-offs), GM %, EBITDA %, PAT % |
| Returns | ROCE %, ROE % |
| Working capital | WC days, inventory days, receivable/payable days, inventory % of sales |
| Cash | CFO, capex, FCF post-dividend, FCF yield %, FCF/EBITDA conversion % |
| Growth | revenue growth %, volume growth %, value growth %, expected growth % |
| Consumption | A&P % of sales, distribution reach (outlets), rural/urban mix |
| Retail/QSR (if applicable) | SSSG/LFL %, store count growth %, average store payback |
| Durables (if applicable) | channel mix % (e-comm/GT/MT), inventory turnover |

**Relative-valuation justifier:** premium/discount vs GM stability (pricing power) and distribution-driven ROCE stability.

**Preferred sources:** company decks/transcripts, NielsenIQ/Kantar citations in press, IMD monsoon data, state excise policies (liquor), Screener/Tickertape for peer financials.
