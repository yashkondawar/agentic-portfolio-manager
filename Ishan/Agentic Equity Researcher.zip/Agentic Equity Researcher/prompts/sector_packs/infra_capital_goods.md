# Sector Pack — Infrastructure & Capital Goods (EPC, construction, power equipment, rail/road)
*Shared rules live in prompts/31.*

**Core truth:** the P&L is a lagging indicator; the balance sheet (working capital, mobilization advances, retention money, contingent liabilities) is where EPC companies live or die. Order book quality > order book size.

## Qualitative lenses
- **Execution moat**: completed-on-time track record, escalation clauses in contracts (commodity protection), site/labor mobilization scale.
- **Model check**: EPC (asset-light) vs BOT/HAM (capital-locked) mix — verify the *claimed* shift in the actual balance sheet (contingent liabilities, SPV loans, equity commitments to HAM projects).
- **Order book quality**: counterparty split (central vs state vs private — state discoms/bodies are the slow payers), segment split, aging, margin cohort of recent wins (aggressive bidding cycles show up 2 years later).
- **De-risking**: asset monetization (InvIT sales), debt trajectory, promoter pledge (chronic in this sector).
- **Government dependence**: budget capex trajectory, NIP/scheme pipelines, election-cycle award/execution rhythm; payment-cycle behaviour around fiscal year-end.
- **Counterparty risk**: SEB exposure on PPAs (power), MoD/railways payment terms — quantify receivable days by counterparty where disclosed.

## KPI table rows (target + peers)
| Category | KPIs |
|---|---|
| Valuation | price date, mcap, EV, P/E (LTM), forward P/E, EV/EBITDA |
| Profitability | revenue, EBITDA, PAT (ex one-offs), EBITDA %, ROCE %, ROE % |
| Visibility | **order book, book-to-bill (x)**, order inflow YoY %, order book by counterparty % |
| Working capital | **receivable days, WC days**, mobilization advances, retention money |
| Risk | net debt/EBITDA, D/E, interest coverage, **contingent liabilities % of net worth** |
| Model | EPC revenue % vs BOT/HAM, govt contracts % of revenue |
| Cash | CFO, capex, FCF, FCF/EBITDA % (chronically weak here — compare, don't excuse) |

**Relative-valuation justifier:** premium vs WC discipline (receivable days), execution moat (book-to-bill with on-time record), and de-risking progress (net debt/EBITDA trend) — apply a working-capital-lockup haircut mentally before comparing P/Es.

**Preferred sources:** company order-inflow disclosures, MoRTH/NHAI award data, budget documents, CEA for power, rating-agency reports on group leverage.
