# Sector Pack — Auto & Engineering (OEMs, ancillaries, defense manufacturing, industrials)
*Shared rules live in prompts/31.*

**Core truth:** deeply cyclical with operating leverage — CV volumes proxy GDP/freight, PV volumes proxy consumer credit & sentiment, 2W volumes proxy rural cash flow. The margin story is utilization × commodity lag × mix.

## Qualitative lenses
- **Cycle position**: where each sub-segment is (CV/PV/2W/tractor), dealer inventory levels vs norms, registration (VAHAN) vs wholesale divergence.
- **Operating leverage**: utilization, break-even proxy, incremental margin history through last cycle.
- **Commodity sensitivity**: steel/aluminum lag pass-through mechanics per peer (quarterly lag clauses vs spot).
- **EV transition**: ICE-exposure of the portfolio; EV content-per-vehicle delta (is the peer's part worth more or less in an EV?); credible EV wins vs press releases; FAME/PLI subsidy dependence of demand.
- **Defense/rail (if applicable)**: indigenization-list moat vs MoD receivable days; order inflow lumpy-ness, execution ramp credibility.
- **Ancillaries**: platform concentration, export content, tooling amortization; scrappage-policy effect on replacement demand.

## KPI table rows (target + peers)
| Category | KPIs |
|---|---|
| Valuation | price date, mcap, EV, P/E (LTM), forward P/E, EV/EBITDA |
| Profitability | revenue, EBITDA, PAT (ex one-offs), GM %, EBITDA %, ROCE %, ROE % |
| Efficiency | capacity utilization %, WC days, inventory days, dealer inventory days |
| Volumes | segment volume growth % (CV/PV/2W/tractor as applicable), exports % of sales |
| EV/Ancillary | EV revenue %, content per vehicle (₹, estimate if unreported — label), kit value trend |
| Defense/Engineering | orderbook, book-to-bill, govt receivable days, contingent liabilities % net worth |
| Cash | CFO, capex, FCF, FCF yield %, FCF/EBITDA % |

**Relative-valuation justifier:** premium vs cycle timing (leading vs lagging volume growth), operating-leverage headroom (utilization), and EV-transition hedge (CPV in EVs) — cyclicals get peak multiples on trough earnings, not the reverse; state where we are.

**Preferred sources:** SIAM/FADA/VAHAN data, company monthly volume disclosures, MoD/MoRTH announcements, steel/aluminum indices.
