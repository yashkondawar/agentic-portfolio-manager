# Sector Pack — IT & Technology (services, ER&D, SaaS, new-age/platforms)
*Shared rules live in prompts/31.*

**Core truth:** human-capital arbitrage → asset-light high ROCE; the durability question is non-linearity (revenue per employee) and AI's effect on both utilization and pricing.

## Qualitative lenses
- **Non-linear growth**: revenue growth vs headcount growth divergence; platform/IP revenue share.
- **Margin levers**: pyramid (fresher %), subcontracting %, offshore/onsite mix, utilization — who has slack left.
- **Demand**: client-sector IT budgets (US/EU BFSI, retail, hi-tech), large-deal TCV pipeline and tenure, vendor-consolidation win/loss.
- **AI/GenAI disruption (mandatory)**: effect on pricing of core services, productivity pass-through demands from clients, each peer's monetization posture (evidence, not vendor slogans).
- **Talent**: attrition trend, wage inflation for niche skills (cloud/cyber/data), replacement-cost drag.
- **FX**: USD-INR natural hedge extent; hedging policy.
- **Niche**: ER&D — revenue stickiness, % ER&D mix; SaaS — NRR, gross churn, Rule of 40; new-age — take rate, path to EBITDA breakeven, CAC trends.

## KPI table rows (target + peers)
| Category | KPIs |
|---|---|
| Valuation | price date, mcap, P/E (LTM), forward P/E, EV/EBITDA |
| Profitability | revenue (₹ + USD), EBITDA, PAT (ex one-offs), EBIT margin %, ROCE %, ROE % |
| Efficiency | utilization %, offshore mix %, subcontracting % of revenue |
| Talent | attrition % (LTM), headcount, net adds, **revenue per employee (USD)** |
| Demand | large deal TCV, book-to-bill, top-10 client concentration % |
| Cash | CFO, FCF, FCF yield %, payout %, FCF/EBITDA % |
| SaaS (if applicable) | NRR %, ARR growth %, Rule of 40 |
| New-age (if applicable) | take rate %, adjusted EBITDA margin, CAC/LTV |

**Relative-valuation justifier:** P/E premium vs revenue-per-employee trajectory, attrition differential, and evidenced AI-defense — growth quality over growth quantity.

**Preferred sources:** company factsheets (they disclose utilization/attrition), NASSCOM, Gartner/IDC citations, USD reporting where available.
