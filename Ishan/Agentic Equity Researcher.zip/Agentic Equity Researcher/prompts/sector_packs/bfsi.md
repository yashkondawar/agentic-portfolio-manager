# Sector Pack — BFSI (Banks, NBFCs, HFCs, MFIs, Insurers, capital-market infra)
*Shared rules live in prompts/31. This pack = what to look at and why, for this sector.*

**Core truth:** lenders win by pricing the next rupee of risk correctly; sustainable ROA/ROE comes from liability franchise + underwriting, not growth. Book value quality (true provisioning, through-cycle stability) is the real number under the printed number.

## Qualitative lenses
- **Liability franchise**: CASA quality and stickiness, cost of funds trajectory, wholesale-funding reliance (CP dependence for NBFCs) and ALM pressure under rate moves.
- **Asset mix & underwriting**: secured vs unsecured mix, segment seasoning, collection efficiency, restructured-book history; digital acquisition cost benchmarking.
- **Regulatory moat & risk**: RBI/IRDAI/SEBI posture (licenses, digital-lending rules, Basel/capital norms); recent/impending regulation from RBI/SEBI papers.
- **Cycle overlay**: P/B premium justified by ROA/ROE stability or just valuation cycle? Credit-cycle stage vs book quality risk (easy-money vintages sour later — check vintage disclosures).
- **Niche**: life insurers — VNB margin, protection vs savings mix, non-par growth; HFCs — rate sensitivity, regional registration volumes; MFIs — state concentration & waiver/political risk; AMCs/depositories/exchanges — take rates, market-linked volumes, float income.
- Stress-test results on loan books where published.

## KPI table rows (target + peers)
| Category | KPIs |
|---|---|
| Valuation | price date, mcap, P/B, P/E (LTM), forward P/E |
| Profitability | NII, PPOP, PAT (ex one-offs), EPS diluted, NIM % |
| Returns | ROA %, ROE %, (ROCE where meaningful) |
| Asset quality | GNPA %, NNPA %, PCR %, credit cost %, restructured % |
| Capital | CET1 %, CAR %, leverage (assets/equity) |
| Franchise | CASA %, cost of funds %, cost-income % |
| Growth | loan book/AUM YoY %, deposit YoY %, disbursement YoY % |
| Insurance (if applicable) | VNB margin %, APE growth %, persistency, solvency ratio |

**Relative-valuation justifier:** P/B premium/discount vs sustained ROA/ROE and book-value quality — include the P/B-vs-ROE cross-sectional read across peers (who's off the regression line and why).

**Preferred sources:** RBI DBIE & circulars, IRDAI, company investor decks (NIM/GNPA walk slides), exchange filings, rating-agency reports (CRISIL/ICRA/CARE) for funding mix.

**Note:** BFSI statements differ — extraction uses the BFSI addendum; inventory/receivable-days ratios are meaningless here and are skipped by the ratio script.
