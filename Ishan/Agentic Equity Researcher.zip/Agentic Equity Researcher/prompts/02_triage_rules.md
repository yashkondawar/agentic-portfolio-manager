# Triage Rules — rule-based branching (run once after intake; re-run only if intake changes)

Purpose: make the "dynamic, not a flow" ordering **explainable**. Each decision below records: rule id, inputs examined, decision, reason — into `state/triage.json` and `state/run_log.md`.

## T1. Input inventory classification

Classify every file in `input/<TICKER>/` into: `annual_report`, `quarterly_result`, `transcript`, `presentation`, `deep_research_prior` (DR1/DR2-style outputs supplied by user), `peer_material`, `kpi_data`, `other_disclosure`. Extract fiscal period from content, not filename, when ambiguous.
- If prior deep research exists → mark corresponding research tasks `prefilled`; deep-researcher only validates freshness (> 6 months old → refresh headline numbers) and fills gaps. **Do not redo supplied research.**
- Ideal set is 5 ARs / 6 quarterlies / 5 transcripts / 5 presentations, but run with whatever exists; list shortfalls in `manifest.json.gaps` (they become report disclosures, not blockers).

## T2. Sector pack selection

From latest AR business description + segment note:
- Bank / NBFC / HFC / MFI / insurer / AMC / broker / depository → `bfsi` (also sets `bfsi_statements: true` → extraction uses BFSI addendum; non-applicable manufacturing ratios skipped)
- FMCG, retail, QSR, durables, apparel, footwear, liquor → `consumer_retail`
- Metals, mining, cement, oil & gas, power, utilities, CGD → `commodities_energy`
- IT services, SaaS, platforms, internet, ER&D → `it_technology`
- Pharma, API, CDMO, specialty chemicals, agrochem → `pharma_chemicals`
- OEM, auto ancillary, defense manufacturing, industrials/engineering products → `auto_engineering`
- EPC, construction, infra developers, capital goods, railways/road contractors → `infra_capital_goods`
- Anything else / conglomerate with no dominant segment → `generic`
Multi-segment company: pick pack of the largest-EBIT segment as primary; list secondary packs — deep research applies the primary pack fully and pulls only the KPI table from secondary packs.

## T3. Research order (the architecture decision)

- **R-PURE**: exactly 1 reportable segment AND revenue mix stable (largest segment ≥ 85% of revenue in each of last 3 FYs) AND no M&A/demerger/large capex-driven new line in last 2 years → industry is already known ⇒ **launch DR2 (sector/peers) immediately, in parallel with extraction.** DR1 (company/management) launches with it.
- **R-SEGMENT**: segment count > 1 OR mix shift > 5pp YoY OR M&A/demerger/carve-out in last 2 years → **extraction first**, build the segment map, then branch DR2 per active segment (primary pack + secondary KPI pulls). DR1 can still start immediately (management background does not depend on segments).
- **R-PIVOT**: strategy pivot signals (new segment announced in transcripts, > 30% capex into a new line) → after extraction, run DR2 for BOTH legacy and target industry; weight by capital allocation, not current revenue.

## T4. Basis (standalone vs consolidated)

Both extracted when both published. Primary basis for analysis/valuation = consolidated when subsidiaries are material (subsidiary revenue > 10% of consolidated or explicit holding structure); else standalone. Record choice + reason; the standalone-vs-consolidated comparison table is mandatory either way.

## T5. Market data

If ticker resolvable → `tools/market_data.py` at intake (always; it feeds euphoria/panic signals, FY-average prices, mcap history for the historical-multiples table). Not resolvable/offline → open question `severity: high` routed to deep research with explicit warning that web-sourced prices are second-best evidence.

## T6. Peer seed list

Peers named in provided documents (AR competition section, presentations, prior research) → seed list with sources. DR2 extends to ≤ 8 domestic + ≤ 8 international comparable-by-business-model; every addition records query + source + retrieval date; business-model deltas vs target noted per peer.

## T7. Data mode (sparse vs normal)
Set `data_mode` from the manifest: `sparse` when the document set is thin (e.g. ≤2 annual reports, or only a few quarterlies, or a single AR + a deck, with no transcript history / peer material / prior DR); else `normal`. `sparse` selects the branch in `prompts/70_sparse_data_playbook.md` — same structure, more weight on the business-model spine + external anchoring, estimates published as a confidence-capped range. Record the trigger.

## T8. Dispatch the business-model map (module 03) — do this EARLY
Immediately after triage (before the deep analysis wave), dispatch `prompts/03_business_model_and_value_chain.md` → `state/business_model.json` (value-chain map + company-specific KPI tree + unit economics + swing drivers + net-long/short + research seeds). This artifact steers extraction depth, the `compute_kpis.py` KPI computer, DR2's research seeds, and the report's exhibits. It is the single highest-leverage step (see `docs/PROCESS_V2_REIMAGINED.md`); do NOT defer value-chain thinking to the research wave. It is cheap (~1 sonnet pass on the latest AR's business/segment/MD&A sections) and pays for itself downstream. In `sparse` mode it matters MORE, not less — it is built from first principles + one AR.
