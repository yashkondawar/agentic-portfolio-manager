# NALCO — operating KPI trends

*Computed by tools/compute_kpis.py from extracted volume/segment facts. Interpretation (why a KPI moved) is the analyst's job — this is the data, not the read.*

## Standalone — 4 KPIs x 4 periods

| KPI | unit | FY2021 | FY2022 | FY2024 | FY2025 | YoY (last FY) |
|---|---|---|---|---|---|---|
| aluminium_ebit_contribution | pct | 57.71 | 74.29 | 61.21 | 55.49 | -9.3% |
| aluminium_segment_ebit_margin | pct | 13.85 | 31.98 | 15.97 | 36.40 | +127.9% |
| chemical_ebit_contribution | pct | 42.29 | 25.71 | 38.79 | 44.51 | +14.8% |
| chemical_segment_ebit_margin | pct | 16.09 | 20.97 | 17.86 | 42.66 | +138.9% |

