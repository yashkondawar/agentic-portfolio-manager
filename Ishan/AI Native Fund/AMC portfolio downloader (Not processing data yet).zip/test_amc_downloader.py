"""
Test suite for amc_downloader.py, covering the pieces that were actually
verified during development (see README.md 'Important caveats'):

  - Date/period extraction against every real label & filename format
    observed while researching AMC sites (catches the 2-digit-year bug).
  - Static HTML scraping + monthly-vs-fortnightly/factsheet keyword
    filtering, against a synthetic page mirroring Nippon India MF's real
    structure.
  - The dynamic (Playwright) dropdown-scraping mechanics against a local
    mock page, including the stale-result regression test.

Run with: python -m pytest test_amc_downloader.py -v
      or: python test_amc_downloader.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import amc_downloader as mod


# ---------------------------------------------------------------------------
# Date / period extraction
# ---------------------------------------------------------------------------

DATE_CASES = [
    ("Monthly portfolio for the month of March 2026", (2026, 3)),
    ("Monthly portfolio as on 30th April 2025", (2025, 4)),
    ("Monthly portfolio for the month end 31st July 2015", (2015, 7)),
    ("Monthly portfolio for the month of\u200b \u200bNovember 2025", (2025, 11)),
    ("Debt Schemes Portfolio as on 15th June 2025", (2025, 6)),
    ("Monthly portfolio as on 28th February 2025", (2025, 2)),
    ("Fundamentals - August 2019", (2019, 8)),
    ("NIMF-MONTHLY-PORTFOLIO-31-May-26.xls", (2026, 5)),
    ("NIMF-MONTHLY-PORTFOLIO-30-April-25.xls", (2025, 4)),
    ("MONTHLY-PORTFOLIO-DEC-23.xls", (2023, 12)),               # 2-digit year regression case
    ("Reliance-Monthly-Portfolios-31.12.2015.xls", (2015, 12)),
    ("NIMF_MONTHLY_PORTFOLIO_31-Jan-25.xls", (2025, 1)),
    ("Reliance-Monthly-Portfolios-28.02.2018.xls", (2018, 2)),
    ("MONTHLY-PORTFOLIO-REPORT-March-24.xls", (2024, 3)),        # 2-digit year regression case
    ("Reliance-Monthly-Portfolios-30.11.2018.xls", (2018, 11)),
    ("NIMF-MONTHLY-PORTFOLIO-Nov-25.xls", (2025, 11)),
    ("Some totally unrelated file.pdf", None),
]


def test_extract_year_month():
    for text, expected in DATE_CASES:
        got = mod.extract_year_month(text)
        assert got == expected, f"{text!r}: expected {expected}, got {got}"


def test_compute_target_periods_wraps_year_boundary():
    from datetime import date
    periods = mod.compute_target_periods(4, as_of=date(2026, 2, 1))
    assert periods == [(2026, 2), (2026, 1), (2025, 12), (2025, 11)]


# ---------------------------------------------------------------------------
# Static HTML scraper + keyword filtering
# ---------------------------------------------------------------------------

SAMPLE_HTML = """
<html><body><div class="page-content"><ul>
  <li>Debt Schemes Portfolio as on 30th June 2026
    <a href="/Docs/NIMF-FORTNIGHTLY-PORTFOLIO-30-Jun-26.xls">Download</a></li>
  <li>E- Factsheet: June 2026
    <a href="/Docs/Nippon-FS-JUNE-2026.pdf">Download</a></li>
  <li>Monthly portfolio for the month of June 2026
    <a href="/Docs/NIMF-MONTHLY-PORTFOLIO-30-Jun-26.xls">Download</a></li>
  <li>Monthly portfolio for the month of May 2026
    <a href="/Docs/NIMF-MONTHLY-PORTFOLIO-31-May-26.xls">Download</a></li>
</ul></div></body></html>
"""


def test_matches_disclosure_keywords():
    assert mod.matches_disclosure_keywords(
        "Monthly portfolio for the month of June 2026", mod.DEFAULT_INCLUDE_KEYWORDS, mod.DEFAULT_EXCLUDE_KEYWORDS
    )
    assert not mod.matches_disclosure_keywords(
        "Debt Schemes Portfolio as on 30th June 2026 (Fortnightly)",
        mod.DEFAULT_INCLUDE_KEYWORDS, mod.DEFAULT_EXCLUDE_KEYWORDS,
    )
    assert not mod.matches_disclosure_keywords(
        "E- Factsheet: June 2026", mod.DEFAULT_INCLUDE_KEYWORDS, mod.DEFAULT_EXCLUDE_KEYWORDS
    )


def test_static_scraper_end_to_end(tmp_path=None, monkeypatch=None):
    """Pure function test, no network/mock library required."""
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(SAMPLE_HTML, "lxml")
    links = []
    for a in soup.find_all("a", href=True):
        href = a["href"]
        if not mod.FILE_EXT_RE.search(href):
            continue
        container = a.find_parent(["li", "p", "div", "tr"])
        label = container.get_text(" ", strip=True) if container else a.get_text(strip=True)
        if not mod.matches_disclosure_keywords(label, mod.DEFAULT_INCLUDE_KEYWORDS, mod.DEFAULT_EXCLUDE_KEYWORDS):
            continue
        period = mod.extract_year_month(label)
        links.append((period, href))
    assert len(links) == 2, f"Expected 2 monthly links (fortnightly/factsheet excluded), got {links}"
    periods = {p for p, _ in links}
    assert periods == {(2026, 6), (2026, 5)}


# ---------------------------------------------------------------------------
# Dynamic (Playwright) scraper mechanics -- requires `playwright install chromium`
# ---------------------------------------------------------------------------

def test_dynamic_scraper_no_stale_results_across_queries():
    """Regression test for the stale-page-state bug: sequential queries on
    fresh pages must each return their OWN month's result, not the previous
    query's leftover data."""
    if not mod.PLAYWRIGHT_AVAILABLE:
        print("SKIPPED (playwright not installed)")
        return

    mock_path = Path(__file__).resolve().parent / "mock_amc_site.html"
    if not mock_path.exists():
        print("SKIPPED (mock_amc_site.html fixture not present)")
        return

    import logging
    log = logging.getLogger("test")
    log.addHandler(logging.NullHandler())

    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        try:
            for year, month, expected_substr in [(2026, 5, "May-2026"), (2026, 6, "June-2026"), (2026, 5, "May-2026")]:
                context = browser.new_context()
                page = context.new_page()
                links = mod.generic_dropdown_scrape(
                    page, "Mock AMC", f"file://{mock_path}", year, month, log
                )
                context.close()
                assert len(links) == 1, f"{year}-{month}: expected 1 link, got {links}"
                assert expected_substr in links[0].url, f"{year}-{month}: got wrong/stale result {links[0].url}"
        finally:
            browser.close()


if __name__ == "__main__":
    tests = [
        test_extract_year_month,
        test_compute_target_periods_wraps_year_boundary,
        test_matches_disclosure_keywords,
        test_static_scraper_end_to_end,
        test_dynamic_scraper_no_stale_results_across_queries,
    ]
    failures = 0
    for t in tests:
        try:
            t()
            print(f"PASS  {t.__name__}")
        except AssertionError as e:
            failures += 1
            print(f"FAIL  {t.__name__}: {e}")
    print(f"\n{len(tests) - failures}/{len(tests)} passed")
    sys.exit(1 if failures else 0)
