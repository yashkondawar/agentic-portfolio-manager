# AMC Monthly Portfolio Disclosure Downloader

Downloads SEBI-mandated **monthly portfolio disclosure** Excel files, published
by Indian Mutual Fund AMCs on their own websites, for the last N months.

## Read this before running it

This tool was built by actually researching AMFI's directory and several AMC
websites, rather than assuming a pattern would work. Three things came out of
that research that materially shape what this script can and can't do
out-of-the-box:

**1. AMFI's own page can't be scraped directly.**
`amfiindia.com/online-center/portfolio-disclosure` is a JavaScript-rendered
page — a plain HTTP request returns an empty shell with no AMC list in it.
That's not a blocker for the actual goal, though: AMFI is only a *directory*.
SEBI's disclosure regulation requires every AMC to publish this data on its
**own** website regardless, so this script goes straight to each AMC's site
instead of trying to scrape AMFI's.

**2. AMC websites split into two genuinely different architectures.**
- **Static** sites (Nippon India Mutual Fund, confirmed) still render a plain
  HTML page with a real `<a href="...xls">` link for every past month. These
  are scraped with `requests` + BeautifulSoup — fast, no browser needed.
- **Dynamic** sites (HDFC, SBI, Kotak, and most large AMCs as of mid-2026,
  confirmed) have been rebuilt as JavaScript single-page apps: you pick
  Frequency / Year / Month from dropdowns and an AJAX call fills in a results
  table. These need a real browser (Playwright) to work at all.

**3. Every AMC entry is honestly labeled with how much to trust it.**
Only a handful of AMCs were actually verified in the research behind this
tool (limited by how many live sites could reasonably be checked). The other
~40 are included as **names only**, confirmed current from a mutual-fund
forms directory, with no URL guessed or invented. See the status table below
and `amc_config.json`'s `notes` field for each one.

This means: out of the box, this reliably downloads from **1 AMC** (Nippon
India), attempts **3 more** with best-effort browser automation that may need
selector tweaks (HDFC, SBI, Kotak), flags **1** with a known URL problem
(ICICI Prudential), and clearly skips the rest until you configure them. See
["Adding more AMCs"](#adding-more-amcs) below — it's meant to be extended.

## Setup

```bash
pip install -r requirements.txt
playwright install chromium   # one-time, needed for dynamic-site AMCs
```

## Usage

```bash
# See every AMC in the registry and its status
python amc_downloader.py --list-amcs

# Download the last 6 months from every configured AMC
python amc_downloader.py --months 6

# Just specific AMCs
python amc_downloader.py --months 3 --amcs "Nippon India Mutual Fund" "SBI Mutual Fund"

# Preview what would be downloaded without saving anything
python amc_downloader.py --months 3 --dry-run

# Watch the browser while it works on dynamic sites (for debugging selectors)
python amc_downloader.py --months 1 --amcs "HDFC Mutual Fund" --headed

# Also grab fortnightly (debt-scheme) disclosures, not just monthly
python amc_downloader.py --months 3 --include-fortnightly
```

Downloads land in `downloads/<AMC Name>/<YYYY>-<MM>_<original filename>`,
alongside a timestamped run log (`downloads/_logs/`) and a JSON summary report
(`downloads/_summary_<timestamp>.json`) showing exactly what was found,
downloaded, skipped, or failed for every AMC in scope.

## Current AMC status

| Status | Meaning |
|---|---|
| `verified_static` | Real fetch confirmed genuine per-month links. Should just work. |
| `verified_dynamic` | Real fetch confirmed the URL and dropdown-driven UI. Selectors are best-effort (built from visible label text, not inspected DOM) — check with `--headed`. |
| `url_unconfirmed` | A URL was found via search but errored on direct fetch. Re-verify before relying on it. |
| `unresearched` | Only the AMC name is confirmed current. No URL was looked up. Needs configuring — see below. |

Run `python amc_downloader.py --list-amcs` for the full current list (44 AMCs).

## Adding more AMCs

Open `amc_config.json` and add an entry:

```json
{
  "name": "Exact AMC Name",
  "disclosure_url": "https://.../monthly-portfolio-page",
  "scrape_method": "static_html",
  "verification": "verified_static",
  "notes": "How you confirmed this."
}
```

To figure out `scrape_method`:
1. Open the disclosure page in a normal browser and view source (Ctrl+U /
   Cmd+Option+U), or just try `curl <url>` — if you see real `<a href="...xls">`
   links in the raw HTML, it's `static_html`.
2. If the raw source is basically empty and the content only shows up when
   JavaScript runs (a dropdown for Frequency/Year/Month, "Loading...", etc.),
   it's `playwright_dynamic`. The included `generic_dropdown_scrape()`
   function will *attempt* this automatically by guessing which `<select>` is
   which from its label text — run with `--headed --amcs "New AMC Name"` to
   watch it work (or fail) and adjust `generic_dropdown_scrape()` /
   `_select_best_effort()` if the site's labels don't match the patterns it
   looks for (`freq|type|category`, `year`, `month`).

## Important caveats (found by actually testing this, not assumed)

- **A single shared browser page across sequential month queries returns
  stale results.** Selecting new dropdown values and re-clicking Search on
  the *same* page can return the *previous* query's table, because the
  results element already exists in the DOM and a naive "wait for it to
  appear" check succeeds instantly. The script reloads the page fresh for
  every (year, month) combination specifically to avoid this — don't
  "optimize" that away.
- **A month that isn't published yet is a normal, expected outcome, not an
  error.** Requesting the current month before an AMC has published it will
  correctly return zero results for that month (this takes a few seconds per
  miss, since Playwright still has to try candidate dropdown values before
  concluding the option doesn't exist).
- **Date parsing deliberately avoids naive fuzzy-parsing libraries.**
  Filenames like `MONTHLY-PORTFOLIO-DEC-23.xls` use a 2-digit year that
  generic fuzzy date parsers can silently misread as day-23-of-the-current-
  year. `extract_year_month()` handles this explicitly and is tested against
  every real filename/label format found during research.
- **The robots.txt check can behave oddly inside a network-sandboxed
  environment** (e.g. one that blocks non-whitelisted domains with an HTTP
  403). Python's `urllib.robotparser` treats a 403 while fetching
  `robots.txt` as "disallow everything," so a *network* block can look
  identical to a *real* disallow. On a normal internet connection (which is
  how you'll run this) that ambiguity doesn't arise — you'll get the site's
  actual robots.txt answer. If a site you have good reason to think permits
  this shows up as disallowed, double-check `https://<site>/robots.txt` in
  a browser before assuming the check is wrong.
- **This is a courtesy scraper, not a stress test.** It waits ~1.5s between
  requests, uses a descriptive User-Agent (edit the placeholder email in
  `USER_AGENT` in `amc_downloader.py`), retries failed downloads a few times
  with backoff, and checks robots.txt before hitting each site. Please keep
  these in place — the data is public, but the servers hosting it aren't
  yours.
- **Only "monthly portfolio" disclosures are matched by default**, not
  fortnightly (debt-scheme) disclosures, factsheets, or risk-parameter
  filings, since those are different SEBI-mandated documents that happen to
  live on the same pages. Pass `--include-fortnightly` if you want those too.

## What's next

You mentioned a follow-up step to process the downloaded Excel files — this
script's JSON summary report (with AMC name, period, and local file path for
every download) is meant to be a clean input for that stage.
