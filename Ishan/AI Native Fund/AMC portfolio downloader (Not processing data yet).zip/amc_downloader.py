#!/usr/bin/env python3
"""
AMC Monthly Portfolio Disclosure Downloader
============================================

Downloads SEBI-mandated monthly portfolio disclosure Excel files, published
by Indian Mutual Fund AMCs on their own websites, for the last N months.

WHY THIS ISN'T A SIMPLE ONE-PATTERN SCRAPER
--------------------------------------------
AMFI's own disclosure directory (amfiindia.com/online-center/portfolio-disclosure)
is a JavaScript-rendered page with no static list of AMC links -- it can't be
scraped with a plain HTTP request. More importantly, AMFI is only a directory:
the actual portfolio files always live on each AMC's own website (that's the
SEBI disclosure requirement), so this script targets AMC sites directly.

Those AMC sites split into two genuinely different architectures:

  1. STATIC sites (e.g. Nippon India Mutual Fund) still render a plain HTML
     list with a real <a href="...xls"> link for every past month. These are
     scraped with `requests` + BeautifulSoup -- fast, reliable, no browser
     needed.

  2. DYNAMIC sites (e.g. HDFC, SBI, Kotak and most large AMCs as of mid-2026)
     have been rebuilt as JS single-page apps: you pick Frequency/Year/Month
     from dropdowns and an AJAX call fills in a results table. These need a
     real browser (Playwright) to render the JavaScript and click through the
     filters.

Every entry in amc_config.json is tagged with how confident that entry is:
verified_static / verified_dynamic / url_unconfirmed / unresearched. Please
read amc_config.json's "_readme" field and the per-entry "notes" before
trusting any given AMC's result. Dynamic-site selectors in particular are
best-effort (built from visible label text, not from inspecting live DOM) and
will likely need small adjustments -- run with --headed once per new AMC to
watch what happens and fix selectors in `generic_dropdown_scrape()` below.

USAGE
-----
    pip install -r requirements.txt
    playwright install chromium      # only needed once, for dynamic AMCs

    python amc_downloader.py --list-amcs
    python amc_downloader.py --months 6
    python amc_downloader.py --months 3 --amcs "Nippon India Mutual Fund" "SBI Mutual Fund"
    python amc_downloader.py --months 3 --dry-run
    python amc_downloader.py --months 3 --headed      # watch the browser for dynamic sites
"""

from __future__ import annotations

import argparse
import json
import logging
import re
import sys
import time
import urllib.robotparser
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import Optional
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

try:
    from playwright.sync_api import sync_playwright, Error as PlaywrightError
    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    PLAYWRIGHT_AVAILABLE = False


# ============================================================================
# Constants
# ============================================================================

SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_CONFIG_PATH = SCRIPT_DIR / "amc_config.json"

USER_AGENT = (
    "Mozilla/5.0 (compatible; AMC-Portfolio-Research-Bot/1.0; "
    "personal/research use; contact: set-your-email-here)"
)
REQUEST_TIMEOUT = 30
RETRY_COUNT = 3
RETRY_BACKOFF_SECONDS = 2.0
POLITE_DELAY_SECONDS = 1.5

FILE_EXT_RE = re.compile(r"\.(xlsx?|xlsb|zip|csv)(\?.*)?$", re.IGNORECASE)

DEFAULT_INCLUDE_KEYWORDS = ["monthly portfolio"]
DEFAULT_EXCLUDE_KEYWORDS = [
    "fortnightly", "risk parameter", "factsheet", "fundamentals",
    "riskometer", "half yearly", "half-yearly", "annual report",
]

MONTH_MAP = {
    "jan": 1, "january": 1, "feb": 2, "february": 2, "mar": 3, "march": 3,
    "apr": 4, "april": 4, "may": 5, "jun": 6, "june": 6, "jul": 7, "july": 7,
    "aug": 8, "august": 8, "sep": 9, "sept": 9, "september": 9, "oct": 10,
    "october": 10, "nov": 11, "november": 11, "dec": 12, "december": 12,
}
_MONTH_ALTS = "|".join(sorted(MONTH_MAP.keys(), key=len, reverse=True))
MONTH_RE = re.compile(rf"\b({_MONTH_ALTS})\b", re.IGNORECASE)
YEAR4_RE = re.compile(r"\b(19|20)\d{2}\b")
ORDINAL_NUM_RE = re.compile(r"\b\d{1,2}(?:st|nd|rd|th)\b", re.IGNORECASE)
BARE_2DIGIT_RE = re.compile(r"\b\d{2}\b")
NUMERIC_DATE_RE = re.compile(r"\b(\d{1,2})[.\-/](\d{1,2})[.\-/](\d{2,4})\b")
MONTH_NAME_BY_NUM = {v: k for k, v in {
    1: "January", 2: "February", 3: "March", 4: "April", 5: "May", 6: "June",
    7: "July", 8: "August", 9: "September", 10: "October", 11: "November",
    12: "December",
}.items()}
MONTH_FULLNAME = {
    1: "January", 2: "February", 3: "March", 4: "April", 5: "May", 6: "June",
    7: "July", 8: "August", 9: "September", 10: "October", 11: "November",
    12: "December",
}


# ============================================================================
# Logging
# ============================================================================

def setup_logging(log_dir: Path) -> logging.Logger:
    log_dir.mkdir(parents=True, exist_ok=True)
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    log_path = log_dir / f"run_{timestamp}.log"

    logger = logging.getLogger("amc_downloader")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()

    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", "%H:%M:%S")

    console = logging.StreamHandler(sys.stdout)
    console.setFormatter(fmt)
    logger.addHandler(console)

    file_handler = logging.FileHandler(log_path, encoding="utf-8")
    file_handler.setFormatter(fmt)
    logger.addHandler(file_handler)

    logger.info(f"Logging to {log_path}")
    return logger


# ============================================================================
# Date / period extraction  (tested against real observed label & filename
# formats from Nippon India MF -- see project notes)
# ============================================================================

def extract_year_month(raw_text: str) -> Optional[tuple[int, int]]:
    """Best-effort (year, month) extraction from disclosure label text or a
    filename. Returns None if no confident match is found. Deliberately
    avoids naive dateutil fuzzy-parsing, which silently misreads 2-digit
    years like 'DEC-23' as day-of-month-23-of-the-current-year."""
    if not raw_text:
        return None
    text = raw_text.replace("\u200b", " ").replace("\ufeff", " ")
    text = re.sub(r"[_.]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()

    month_match = MONTH_RE.search(text)

    if not month_match:
        m = NUMERIC_DATE_RE.search(raw_text)
        if not m:
            return None
        d, mo, y = m.groups()
        mo, y = int(mo), int(y)
        if y < 100:
            y += 2000
        if 1 <= mo <= 12 and 1 <= int(d) <= 31:
            return (y, mo)
        return None

    month = MONTH_MAP[month_match.group(1).lower()]

    year4_match = YEAR4_RE.search(text)
    if year4_match:
        return (int(year4_match.group(0)), month)

    text_wo_ordinals = ORDINAL_NUM_RE.sub(" ", text)
    candidates = BARE_2DIGIT_RE.findall(text_wo_ordinals)
    if candidates:
        year = int(candidates[-1]) + 2000
        return (year, month)

    return None


def compute_target_periods(n_months: int, as_of: Optional[date] = None) -> list[tuple[int, int]]:
    """Returns [(year, month), ...] for the last n_months, most recent first,
    including the current month (it may or may not be published yet -- that's
    fine, unmatched periods are simply not found and are logged as such)."""
    if as_of is None:
        as_of = date.today()
    periods = []
    y, m = as_of.year, as_of.month
    for _ in range(n_months):
        periods.append((y, m))
        m -= 1
        if m == 0:
            m = 12
            y -= 1
    return periods


# ============================================================================
# Keyword filtering (monthly vs fortnightly/factsheet/etc.)
# ============================================================================

def matches_disclosure_keywords(label: str, include_kw: list[str], exclude_kw: list[str]) -> bool:
    t = label.lower()
    if any(bad in t for bad in exclude_kw):
        return False
    return any(good in t for good in include_kw)


# ============================================================================
# robots.txt courtesy check (best-effort -- failures default to "allowed"
# with a warning, since not every site publishes robots.txt and a lookup
# failure shouldn't block a legitimate one-off download)
# ============================================================================

def is_scraping_allowed(url: str, user_agent: str, log: logging.Logger) -> bool:
    try:
        parsed = urlparse(url)
        robots_url = f"{parsed.scheme}://{parsed.netloc}/robots.txt"
        rp = urllib.robotparser.RobotFileParser()
        rp.set_url(robots_url)
        rp.read()
        allowed = rp.can_fetch(user_agent, url)
        if not allowed:
            log.warning(f"robots.txt disallows fetching {url} -- skipping.")
        return allowed
    except Exception as e:
        log.debug(f"Could not check robots.txt for {url} ({e}); proceeding cautiously.")
        return True


# ============================================================================
# Filesystem helpers
# ============================================================================

def sanitize_filename(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*]', "_", name)
    name = re.sub(r"\s+", "_", name.strip())
    return name[:150]


# ============================================================================
# Data classes
# ============================================================================

@dataclass
class DisclosureLink:
    amc_name: str
    label: str
    url: str
    year: int
    month: int


@dataclass
class DownloadOutcome:
    amc_name: str
    label: str
    url: str
    year: int
    month: int
    status: str  # "downloaded" | "skipped_exists" | "failed" | "dry_run"
    path: Optional[str] = None
    error: Optional[str] = None


@dataclass
class AmcRunSummary:
    amc_name: str
    scrape_method: str
    verification: str
    links_found: int = 0
    outcomes: list[DownloadOutcome] = field(default_factory=list)
    skip_reason: Optional[str] = None


# ============================================================================
# Static-site scraper (requests + BeautifulSoup)
# ============================================================================

def discover_links_static(
    amc_entry: dict,
    session: requests.Session,
    target_periods: set[tuple[int, int]],
    include_kw: list[str],
    exclude_kw: list[str],
    log: logging.Logger,
) -> list[DisclosureLink]:
    url = amc_entry["disclosure_url"]
    name = amc_entry["name"]

    if not is_scraping_allowed(url, USER_AGENT, log):
        return []

    try:
        resp = session.get(url, timeout=REQUEST_TIMEOUT)
        resp.raise_for_status()
    except requests.RequestException as e:
        log.error(f"[{name}] Failed to fetch disclosure page: {e}")
        return []

    soup = BeautifulSoup(resp.text, "lxml")
    links: list[DisclosureLink] = []

    for a in soup.find_all("a", href=True):
        href = a["href"]
        if not FILE_EXT_RE.search(href):
            continue

        container = a.find_parent(["li", "p", "div", "tr"])
        label = container.get_text(" ", strip=True) if container else a.get_text(strip=True)

        if not matches_disclosure_keywords(label, include_kw, exclude_kw):
            continue

        period = extract_year_month(label) or extract_year_month(href)
        if period is None:
            log.debug(f"[{name}] Could not determine period for link, skipping: {label[:80]}")
            continue
        if period not in target_periods:
            continue

        full_url = href if href.startswith("http") else urljoin(url, href)
        links.append(DisclosureLink(name, label, full_url, period[0], period[1]))

    return links


# ============================================================================
# Dynamic-site scraper (Playwright) -- BEST EFFORT.
#
# Generic strategy: find <select> elements on the page, guess which one is
# "Frequency"/"Year"/"Month" from their associated label text, set them, then
# click whatever button looks like a search/submit action, then harvest any
# resulting file links. This is deliberately generic rather than hard-coded
# per AMC because none of the exact DOM selectors were verifiable in this
# session (no live network access from the build environment). It WILL need
# adjustment per site -- run with --headed to watch and debug.
#
# CRITICAL: a fresh page.goto() is used for every single (year, month) query.
# Reusing one page across sequential dropdown selections was tested and
# found to silently return the PREVIOUS query's stale results (the results
# element already exists in the DOM, so a naive wait_for_selector succeeds
# immediately without the content actually having updated) -- see project
# notes. Do not "optimize" this into one shared page without re-solving that.
# ============================================================================

SEARCH_BUTTON_PATTERN = re.compile(r"search|submit|view|apply|filter|go\b", re.IGNORECASE)


def _select_best_effort(page, keyword_pattern: str, value_options: list[str], log: logging.Logger) -> bool:
    """Try to find a <select> whose accessible label matches keyword_pattern
    and set it to one of value_options (tried as label text, then as raw
    value). Returns True if something was selected."""
    pattern = re.compile(keyword_pattern, re.IGNORECASE)
    selects = page.locator("select")
    count = selects.count()
    for i in range(count):
        sel = selects.nth(i)
        try:
            label_text = ""
            sel_id = sel.get_attribute("id")
            if sel_id:
                label_loc = page.locator(f'label[for="{sel_id}"]')
                if label_loc.count() > 0:
                    label_text = label_loc.first.inner_text()
            if not label_text:
                label_text = sel.get_attribute("aria-label") or sel.get_attribute("name") or ""
            if not pattern.search(label_text):
                continue
            for value in value_options:
                # explicit short timeout is essential here: Playwright's
                # default action timeout is 30s, and it does NOT fail fast
                # when the given label/value simply doesn't exist among the
                # <option>s -- it keeps retrying actionability checks for
                # the full timeout before raising. Without this, a single
                # not-yet-published month (a routine, expected case) would
                # hang for minutes per attempt (confirmed by testing).
                try:
                    sel.select_option(label=value, timeout=800)
                    return True
                except Exception:
                    pass
                try:
                    sel.select_option(value=value, timeout=800)
                    return True
                except Exception:
                    pass
        except Exception as e:
            log.debug(f"Selector inspection failed on select #{i}: {e}")
    return False


def generic_dropdown_scrape(
    page,
    amc_name: str,
    base_url: str,
    year: int,
    month: int,
    log: logging.Logger,
) -> list[DisclosureLink]:
    month_name = MONTH_FULLNAME[month]
    try:
        page.goto(base_url, wait_until="domcontentloaded", timeout=REQUEST_TIMEOUT * 1000)
    except PlaywrightError as e:
        log.error(f"[{amc_name}] Failed to load {base_url}: {e}")
        return []

    _select_best_effort(page, r"freq|type|category", ["Monthly", "monthly"], log)
    got_year = _select_best_effort(page, r"year", [str(year)], log)
    got_month = _select_best_effort(
        page, r"month", [month_name, month_name[:3], str(month), f"{month:02d}"], log
    )

    if not (got_year or got_month):
        log.warning(
            f"[{amc_name}] Could not identify Year/Month dropdowns automatically for "
            f"{month_name} {year}. This site's selectors need to be inspected manually "
            f"(run with --headed) and added as a custom recipe."
        )
        return []

    clicked = False
    for role, name_pat in (("button", SEARCH_BUTTON_PATTERN), ("link", SEARCH_BUTTON_PATTERN)):
        try:
            btn = page.get_by_role(role, name=name_pat)
            if btn.count() > 0:
                btn.first.click(timeout=5000)
                clicked = True
                break
        except Exception:
            continue

    try:
        page.wait_for_load_state("networkidle", timeout=8000)
    except PlaywrightError:
        pass

    # IMPORTANT: do not read the DOM immediately after networkidle. That
    # event only tracks actual network requests, so it fires almost
    # instantly on pages where the results are populated by a setTimeout,
    # a client-side render tick after a fetch already completed, or any
    # other delay that isn't itself a pending network request -- reading
    # anchors at that instant returns whatever was there BEFORE the click
    # (confirmed by testing: this silently produced 0 results even though
    # the click and dropdown selection both succeeded). Poll briefly for a
    # qualifying file link to actually appear instead of trusting one signal.
    anchors: list[dict] = []
    deadline = time.time() + 4.0
    while time.time() < deadline:
        try:
            anchors = page.eval_on_selector_all(
                "a[href]", "els => els.map(e => ({href: e.href, text: e.innerText || e.textContent}))"
            )
        except PlaywrightError as e:
            log.error(f"[{amc_name}] Could not read result links: {e}")
            return []
        if any(FILE_EXT_RE.search(a.get("href", "")) for a in anchors):
            break
        page.wait_for_timeout(400)

    links = []
    for a in anchors:
        href = a.get("href", "")
        if not FILE_EXT_RE.search(href):
            continue
        label = (a.get("text") or "").strip() or href
        links.append(DisclosureLink(amc_name, label, href, year, month))
    return links


def discover_links_playwright(
    amc_entry: dict,
    browser,
    target_periods: list[tuple[int, int]],
    headed: bool,
    log: logging.Logger,
) -> list[DisclosureLink]:
    name = amc_entry["name"]
    url = amc_entry["disclosure_url"]

    if not is_scraping_allowed(url, USER_AGENT, log):
        return []

    context = browser.new_context(user_agent=USER_AGENT)
    page = context.new_page()
    all_links: list[DisclosureLink] = []

    try:
        for (year, month) in target_periods:
            # Note: unlike the static scraper, no keyword filtering is applied
            # here. The Frequency dropdown was already set to "Monthly" before
            # searching, so the site itself is doing that filtering -- results
            # rows won't necessarily repeat the word "monthly" in their text,
            # and re-applying the static-page keyword filter here could wrongly
            # discard genuine matches.
            found = generic_dropdown_scrape(page, name, url, year, month, log)
            all_links.extend(found)
            time.sleep(POLITE_DELAY_SECONDS)
    finally:
        context.close()

    return all_links


# ============================================================================
# Downloading
# ============================================================================

def download_one(
    session: requests.Session,
    link: DisclosureLink,
    out_dir: Path,
    dry_run: bool,
    log: logging.Logger,
) -> DownloadOutcome:
    amc_dir = out_dir / sanitize_filename(link.amc_name)
    amc_dir.mkdir(parents=True, exist_ok=True)

    original_name = Path(urlparse(link.url).path).name or "file.xlsx"
    local_name = f"{link.year:04d}-{link.month:02d}_{sanitize_filename(original_name)}"
    dest_path = amc_dir / local_name

    if dest_path.exists():
        return DownloadOutcome(link.amc_name, link.label, link.url, link.year, link.month,
                                "skipped_exists", str(dest_path))

    if dry_run:
        log.info(f"[DRY RUN] Would download: {link.label[:70]} -> {dest_path}")
        return DownloadOutcome(link.amc_name, link.label, link.url, link.year, link.month,
                                "dry_run", str(dest_path))

    last_error = None
    for attempt in range(1, RETRY_COUNT + 1):
        try:
            resp = session.get(link.url, timeout=REQUEST_TIMEOUT, stream=True)
            resp.raise_for_status()
            tmp_path = dest_path.with_suffix(dest_path.suffix + ".part")
            with open(tmp_path, "wb") as f:
                for chunk in resp.iter_content(chunk_size=65536):
                    if chunk:
                        f.write(chunk)
            tmp_path.rename(dest_path)
            log.info(f"[{link.amc_name}] Downloaded {MONTH_FULLNAME[link.month]} {link.year}: {dest_path.name}")
            return DownloadOutcome(link.amc_name, link.label, link.url, link.year, link.month,
                                    "downloaded", str(dest_path))
        except requests.RequestException as e:
            last_error = str(e)
            log.warning(f"[{link.amc_name}] Attempt {attempt}/{RETRY_COUNT} failed for {link.url}: {e}")
            if attempt < RETRY_COUNT:
                time.sleep(RETRY_BACKOFF_SECONDS * attempt)

    return DownloadOutcome(link.amc_name, link.label, link.url, link.year, link.month,
                            "failed", error=last_error)


# ============================================================================
# Orchestration
# ============================================================================

def load_config(config_path: Path) -> list[dict]:
    with open(config_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data["amcs"]


def select_amcs(all_amcs: list[dict], requested_names: Optional[list[str]]) -> list[dict]:
    if not requested_names:
        return all_amcs
    wanted = {n.lower() for n in requested_names}
    selected = [a for a in all_amcs if a["name"].lower() in wanted]
    found_names = {a["name"].lower() for a in selected}
    missing = wanted - found_names
    if missing:
        raise SystemExit(f"Unknown AMC name(s): {', '.join(missing)}. Use --list-amcs to see options.")
    return selected


def print_amc_list(all_amcs: list[dict]) -> None:
    print(f"\n{'AMC Name':45} {'Method':18} {'Status':18}")
    print("-" * 83)
    for a in all_amcs:
        print(f"{a['name']:45} {a['scrape_method']:18} {a['verification']:18}")
    print(f"\n{len(all_amcs)} AMCs total. See amc_config.json 'notes' for details on each.\n")


def run(args: argparse.Namespace) -> int:
    config_path = Path(args.config)
    all_amcs = load_config(config_path)

    if args.list_amcs:
        print_amc_list(all_amcs)
        return 0

    out_dir = Path(args.output_dir)
    log = setup_logging(out_dir / "_logs")

    amcs = select_amcs(all_amcs, args.amcs)
    target_periods_list = compute_target_periods(args.months)
    target_periods_set = set(target_periods_list)

    include_kw = DEFAULT_INCLUDE_KEYWORDS + (["fortnightly"] if args.include_fortnightly else [])
    exclude_kw = [k for k in DEFAULT_EXCLUDE_KEYWORDS if k not in include_kw]

    period_desc = ", ".join(f"{MONTH_FULLNAME[m]} {y}" for y, m in target_periods_list)
    log.info(f"Target periods ({args.months} months): {period_desc}")
    log.info(f"AMCs in scope: {len(amcs)}")

    session = requests.Session()
    session.headers.update({"User-Agent": USER_AGENT})

    need_playwright = any(a["scrape_method"] == "playwright_dynamic" for a in amcs)
    browser = None
    playwright_ctx = None
    if need_playwright:
        if not PLAYWRIGHT_AVAILABLE:
            log.error(
                "playwright is not installed but is required for one or more selected AMCs. "
                "Run: pip install playwright && playwright install chromium"
            )
        else:
            playwright_ctx = sync_playwright().start()
            browser = playwright_ctx.chromium.launch(headless=not args.headed)

    summaries: list[AmcRunSummary] = []

    try:
        for amc in amcs:
            name = amc["name"]
            method = amc["scrape_method"]
            summary = AmcRunSummary(name, method, amc["verification"])

            if method == "unconfigured":
                summary.skip_reason = "No disclosure URL configured yet -- see amc_config.json notes."
                log.info(f"[{name}] SKIPPED -- {summary.skip_reason}")
                summaries.append(summary)
                continue

            if amc["verification"] == "url_unconfirmed":
                log.warning(f"[{name}] URL is unconfirmed (see notes) -- attempting anyway, expect possible failure.")

            if method == "static_html":
                links = discover_links_static(amc, session, target_periods_set, include_kw, exclude_kw, log)
            elif method == "playwright_dynamic":
                if browser is None:
                    summary.skip_reason = "playwright unavailable"
                    summaries.append(summary)
                    continue
                links = discover_links_playwright(
                    amc, browser, target_periods_list, args.headed, log
                )
            else:
                summary.skip_reason = f"Unknown scrape_method '{method}'"
                summaries.append(summary)
                continue

            summary.links_found = len(links)
            log.info(f"[{name}] Found {len(links)} matching monthly disclosure link(s) in range.")

            for link in links:
                outcome = download_one(session, link, out_dir, args.dry_run, log)
                summary.outcomes.append(outcome)
                time.sleep(POLITE_DELAY_SECONDS)

            summaries.append(summary)

    finally:
        if browser is not None:
            browser.close()
        if playwright_ctx is not None:
            playwright_ctx.stop()

    write_summary_report(summaries, out_dir, log)
    print_summary_table(summaries)
    return 0


def write_summary_report(summaries: list[AmcRunSummary], out_dir: Path, log: logging.Logger) -> None:
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    report_path = out_dir / f"_summary_{timestamp}.json"
    data = []
    for s in summaries:
        data.append({
            "amc_name": s.amc_name,
            "scrape_method": s.scrape_method,
            "verification": s.verification,
            "links_found": s.links_found,
            "skip_reason": s.skip_reason,
            "outcomes": [
                {
                    "label": o.label, "url": o.url, "year": o.year, "month": o.month,
                    "status": o.status, "path": o.path, "error": o.error,
                }
                for o in s.outcomes
            ],
        })
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    log.info(f"Summary report written to {report_path}")


def print_summary_table(summaries: list[AmcRunSummary]) -> None:
    print(f"\n{'AMC':40} {'Found':>6} {'OK':>5} {'Skip':>5} {'Fail':>5}  Notes")
    print("-" * 100)
    total_ok = total_fail = 0
    for s in summaries:
        ok = sum(1 for o in s.outcomes if o.status in ("downloaded", "dry_run"))
        skip = sum(1 for o in s.outcomes if o.status == "skipped_exists")
        fail = sum(1 for o in s.outcomes if o.status == "failed")
        total_ok += ok
        total_fail += fail
        note = s.skip_reason or ""
        print(f"{s.amc_name:40} {s.links_found:>6} {ok:>5} {skip:>5} {fail:>5}  {note}")
    print("-" * 100)
    print(f"Total files downloaded/would-download: {total_ok}   Total failed: {total_fail}\n")


# ============================================================================
# CLI
# ============================================================================

def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Download last N months of monthly portfolio disclosures from Indian AMC websites.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p.add_argument("--months", type=int, default=3, help="How many months back to fetch (including current month).")
    p.add_argument("--amcs", nargs="*", default=None,
                    help="Specific AMC name(s) to run, exactly as in amc_config.json. Default: all configured AMCs.")
    p.add_argument("--output-dir", default="downloads", help="Root folder for downloaded files, logs, and reports.")
    p.add_argument("--config", default=str(DEFAULT_CONFIG_PATH), help="Path to amc_config.json.")
    p.add_argument("--dry-run", action="store_true", help="Discover and log what would be downloaded, without saving files.")
    p.add_argument("--headed", action="store_true", help="Run the Playwright browser visibly, for debugging dynamic-site selectors.")
    p.add_argument("--include-fortnightly", action="store_true", help="Also include fortnightly (debt-scheme) disclosures.")
    p.add_argument("--list-amcs", action="store_true", help="List all AMCs in the registry with their status, then exit.")
    return p


def main() -> None:
    args = build_arg_parser().parse_args()
    sys.exit(run(args))


if __name__ == "__main__":
    main()
